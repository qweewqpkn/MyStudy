﻿using ProtoBuf;
using UnityEngine;
using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Collections.Generic;
using System.Net;
using System.Threading;
using System.Security.Cryptography.X509Certificates;
using System.Net.Security;

/// <summary>
/// Author:Liutao
/// 断点续传类，提供文件的断点续传下载
/// 支持多文件同时下载，多线程，不阻塞游戏主线程
/// 断点续传过程中产生的文件强制锁定拒绝共享，防止未知操作引起包资源错误
/// 类中不产生任何输出，exception由接口向外传递，由外部决定是否处理，保证功能的单一性
/// </summary>
public class FileDownloadHelper
{

    public const int ERROR_LENGTH_ZERO = 1000; // 下载长度为0
    public const int ERROR_SIZE_NOT_MATCH = 1001; // 下载的长度与获取长度不匹配
    public const int ERROR_MD5_NOT_MATCH = 1002; // MD5不匹配
    public const int ERROR_TRY_MAXINUM_TIMES = 1003; // 达到最大重试次数
    public const int ERROR_URL_IS_NULL = 1004; // 下载链接不存在
    public const int ERROR_TOTAL_SIZE_ZERO = 1005; // 下载总大小为0
    public const int ERROR_CANNOT_CREATE_FILE = 1006; // 下载的长度与获取长度不匹配

    private FileDownloadHelper()
    {
        // Loom.Initialize();
        persistentDataPath = Application.persistentDataPath;
    }

    private static FileDownloadHelper mInstance;

    public static FileDownloadHelper Instance
    {
        get
        {
            if (mInstance == null)
            {
                mInstance = new FileDownloadHelper();
            }
            return mInstance;
        }
    }

    public delegate void DownLoadSuccess(string pPath);
    public delegate void DownLoadUpdate(long currentLength, long totoalLength, string pUrl);
    public delegate void DownloadFailed(int errorCode);
    public delegate void DownloadException(Exception e);

    public delegate void RequestSucess(long fileLength);
    public delegate void RequestFailed(int errorCode);

    private const int ByteBuff = 1024 * 2; // 下载缓冲大小 2K
    private const int ReadWriteTimeOut = 2 * 1000;//超时等待时间 两秒
    private const int TimeOutWait = 5 * 1000;//超时等待时间 五秒
    private const int MaxTryTime = 12; // 最大重试次数

    private ContinueDownloadCacheConfig mDownloadConfig;

    private Dictionary<string, int> TryNumDic = new Dictionary<string, int>();

    private static string persistentDataPath = "";

    public string PersisitentDataPath
    {
        get
        {
            return persistentDataPath;
        }
    }

    private string ConfigSavePath
    {
        get
        {
            return persistentDataPath + "/CacheDownloadData.config";
        }
    }

    private ContinueDownloadCacheConfig DownloadConfig
    {
        get
        {
            if (mDownloadConfig == null)
            {
                // 读取配置
                if (File.Exists(ConfigSavePath))
                {
                    FileStream fs = new FileStream(ConfigSavePath, FileMode.Open);
                    BinaryFormatter bf = new BinaryFormatter();
                    // 反序列化成对象
                    try
                    {
                        mDownloadConfig = (ContinueDownloadCacheConfig)bf.Deserialize(fs);
                    }
                    catch
                    {

                        mDownloadConfig = null;
                    }
                    fs.Close();
                }
                if (mDownloadConfig == null)
                {
                    // 删除该文件
                    File.Delete(ConfigSavePath);
                    mDownloadConfig = new ContinueDownloadCacheConfig();
                    mDownloadConfig.datas = new List<ContinueDownloadData>();
                }
            }
            return mDownloadConfig;
        }
    }

    public void StartContinueDownload(ContinueDownloadRequire pData)
    {
        Thread downloadThread = new Thread(new ParameterizedThreadStart(ContinueDownloadFile));
        downloadThread.Start(pData);
    }

    public void StartRequestAllFileLength(GetUrlsSizeRequire pData)
    {
        Thread downloadThread = new Thread(new ParameterizedThreadStart(ContinueRequestAllFileLength));
        downloadThread.Start(pData);
    }

    private void ContinueDownloadFile(System.Object file)
    {
        if (file == null) return;
        if (file is ContinueDownloadRequire)
        {
            DownLoadFile((ContinueDownloadRequire)file);
        }
    }

    private void ContinueRequestAllFileLength(System.Object file)
    {
        if (file == null) return;
        if (file is GetUrlsSizeRequire)
        {
            RequestAllFileLength((GetUrlsSizeRequire)file);
        }
    }

    private void DownLoadFile(ContinueDownloadRequire pData)
    {
        if (pData == null) return;
        string pUrl = pData.url;
        DownloadFailed pFailed = pData.pFailed;
        long lStartPos = 0;
        long getLength = GetFileContentLength(pUrl);
        if (getLength == 0)
        {
            if (pFailed != null)
            {
                ActionManager.Add(() =>
                {
                    Debug.LogError("Download Failed! Lenght is zero! url: " + pData.url);
                    pFailed(ERROR_LENGTH_ZERO);
                    return true;
                });
            }
            return;
        }

        // 检查是否已存在断点续传内容
        ContinueDownloadData continueData = GetExsitData(pUrl);
        FileStream fs = null;

        if (continueData != null)
        {
            // 检查文件长度是否匹配
            if (continueData.byteLength != getLength)
            {
                if (File.Exists(continueData.cacheFilePath))
                {
                    File.Delete(continueData.cacheFilePath);
                }
                continueData = null;
            }
            // 检查缓存文件是否存在
            else if (File.Exists(continueData.cacheFilePath))
            {
                fs = new FileStream(continueData.cacheFilePath, FileMode.Open, FileAccess.Write, FileShare.None);
                lStartPos = fs.Length;
                fs.Seek(lStartPos, SeekOrigin.Current);//移动文件流中的当前指针

                if (lStartPos == getLength) // 已经下载完成
                {
                    // 下载成功之后的操作
                    DownloadSuccessful(continueData, pData);
                    return;
                }
            }
            else
            {
                continueData = null;
            }
        }

        if (continueData == null) // 如果是空,则表示是新的
        {
            continueData = new ContinueDownloadData(pUrl, getLength);
        }

        if (fs == null)
        {
            CheckDirExist(continueData.cacheFilePath);
            // 删除已有文件
            if (File.Exists(continueData.cacheFilePath))
            {
                File.Delete(continueData.cacheFilePath);
            }
            try
            {
                fs = new FileStream(continueData.cacheFilePath, FileMode.Create, FileAccess.Write, FileShare.None);
            }
            catch (Exception e)
            {
                Debug.LogError(e.ToString());
            }
            lStartPos = 0;
        }

        if (fs == null)
        {
            ActionManager.Add(() =>
            {
                Debug.LogError("Download Failed! Cannot create file! url: " + pData.url);
                pData.pFailed(ERROR_CANNOT_CREATE_FILE);
                return true;
            });
            return;
        }

        SaveCurrentData(continueData);
        Stream ns = null;
        // 获取报文头
        HttpWebRequest request = null;
        try
        {
            request = (HttpWebRequest)WebRequest.Create(pUrl);
            request.ReadWriteTimeout = ReadWriteTimeOut;
            request.Timeout = TimeOutWait;
            if (lStartPos > 0)
                request.AddRange((int)lStartPos);//设置Range值，断点续传

            //向服务器请求，获得服务器回应数据流
            WebResponse respone = request.GetResponse();
            long totalSize = getLength;
            long curSize = lStartPos;

            ns = respone.GetResponseStream();

            byte[] nbytes = new byte[ByteBuff];

            // 读取第一次
            int nReadSize = ns.Read(nbytes, 0, ByteBuff);
            curSize += nReadSize;

            while (nReadSize > 0)
            {
                fs.Write(nbytes, 0, nReadSize);
                nReadSize = ns.Read(nbytes, 0, ByteBuff);
                curSize += nReadSize;
                if (pData.pUpdate != null)
                {
                    ActionManager.Add(() =>
                    {
                        pData.pUpdate(curSize, totalSize, pData.url);
                        return true;
                    });
                }
                fs.Flush();
                if (curSize > totalSize)
                {
                    break;
                }
            }
            if (ns != null)
            {
                ns.Close();
                ns = null;
            }
            if (fs != null)
            {
                fs.Close();
                fs = null;
            }
            if (curSize != totalSize)//文件长度不等于下载长度，下载出错
            {
                if (pFailed != null)
                {
                    ActionManager.Add(() =>
                    {
                        // 删除文件
                        File.Delete(continueData.cacheFilePath);

                        // 清空重试次数
                        if (TryNumDic.ContainsKey(continueData.url))
                        {
                            TryNumDic.Remove(continueData.url);
                        }

                        // 删除下载请求
                        GetExsitData(continueData.url);
                        // 储存下载配置数据
                        SaveCurrentData();

                        Debug.LogError("Download Failed! Size do not match! url: " + pData.url);
                        pFailed(ERROR_SIZE_NOT_MATCH);
                        return true;
                    });
                }
                return;
            }
            if (request != null)
            {
                request.Abort();
            }

            // 下载成功之后的操作
            DownloadSuccessful(continueData, pData);
            return;
        }
        catch (Exception e)
        {
            if (pData.pException != null)
            {
                Debug.LogError("Download Exception occured! Message:" + e.Message + " url:" + continueData.url);
                // 向外传出exception
                pData.pException(e);
            }
            if (request != null)
            {
                request.Abort();
            }
            if (ns != null)
            {
                ns.Close();
                ns = null;
            }
            if (fs != null)
            {
                fs.Close();
                fs = null;
            }
            int num = 0;
            if (TryNumDic.TryGetValue(continueData.url, out num))
            {
                if (num > MaxTryTime)
                {
                    TryNumDic.Remove(continueData.url);
                    if (pFailed != null)
                    {
                        ActionManager.Add(() =>
                        {
                            Debug.LogError("Download Failed! reach maxinum! url: " + pData.url);
                            pFailed(ERROR_TRY_MAXINUM_TIMES);
                            return true;
                        });
                    }
                    ActionManager.Add(() =>
                    {
                        Debug.LogError("Download return:" + num);
                        return true;
                    });
                    return;
                }
                else
                {
                    TryNumDic[continueData.url]++;
                }
            }
            else
            {
                TryNumDic.Add(continueData.url, 1);
            }

            ActionManager.Add(() =>
            {
                if( TryNumDic != null && continueData != null && TryNumDic.ContainsKey(continueData.url))
                    Debug.LogError("Download Failed!Try later! url:" + continueData.url + "-----num:" + TryNumDic[continueData.url]);
                return true;
            });
            Thread.Sleep(100);
            DownLoadFile(pData);
        }
    }

    private void RequestAllFileLength(GetUrlsSizeRequire pData)
    {
        if (pData == null) return;
        string[] urls = pData.urls;
        RequestSucess pSucess = pData.pSuccess;
        RequestFailed pFailed = pData.pFailed;

        if (urls == null)
        {
            if (pFailed != null)
            {
                ActionManager.Add(() =>
                {
                    Debug.LogError("Download Failed! url is null!");
                    pFailed(ERROR_URL_IS_NULL);
                    return true;
                });
            }
            return;
        }

        long result = 0;
        for (int i = 0; i < urls.Length; ++i)
        {
            result += GetFileContentLength(urls[i]);
        }

        if (result == 0)
        {
            if (pFailed != null)
            {
                ActionManager.Add(() =>
                {
                    Debug.LogError("Download Failed! Total size is null!");
                    pFailed(ERROR_TOTAL_SIZE_ZERO);
                    return true;
                });
            }
        }
        else
        {
            if (pSucess != null)
            {
                ActionManager.Add(() =>
                {
                    Debug.Log("Download successed!");
                    pSucess(result);
                    return true;
                });
            }
        }
    }

    private void SaveCurrentData(ContinueDownloadData pData = null)
    {
        if (pData != null)
        {
            DownloadConfig.datas.Add(pData);
        }

        CheckDirExist(ConfigSavePath);
        FileStream fs = new FileStream(ConfigSavePath, FileMode.OpenOrCreate);
        BinaryFormatter bf = new BinaryFormatter();
        bf.Serialize(fs, DownloadConfig);
        fs.Close();
    }

    private void DownloadSuccessful(ContinueDownloadData continueData, ContinueDownloadRequire pRequireData)
    {
        // 如果传入了文件hash值，则做hash校验，不同则重下
        if (!string.IsNullOrEmpty(pRequireData.hashMD5))
        {
            string fileHash = HashHelper.ComputeMD5(continueData.cacheFilePath);
            // hash不同则重下
            if (!fileHash.Equals(pRequireData.hashMD5))
            {
                // 删除文件
                File.Delete(continueData.cacheFilePath);

                // 重下
                int num = 0;
                if (TryNumDic.TryGetValue(continueData.url, out num))
                {
                    if (num > MaxTryTime)
                    {
                        TryNumDic.Remove(continueData.url);
                        if (pRequireData.pFailed != null)
                        {
                            ActionManager.Add(() =>
                            {
                                Debug.LogError("Download Failed!Md5 do not match! url:" + continueData.url);
                                pRequireData.pFailed(ERROR_MD5_NOT_MATCH);
                                return true;
                            });
                        }
                        return;
                    }
                    else
                    {
                        TryNumDic[continueData.url]++;
                    }
                }
                else
                {
                    TryNumDic.Add(continueData.url, 1);
                }
                ActionManager.Add(() =>
                {
                    Debug.LogError("Download Failed MD5 not match!Try later! url:" + continueData.url + "-----num:" + TryNumDic[continueData.url]);
                    return true;
                });
                Thread.Sleep(100);
                DownLoadFile(pRequireData);

                return;
            }
        }
        // 清空重试次数
        if (TryNumDic.ContainsKey(continueData.url))
        {
            TryNumDic.Remove(continueData.url);
        }

        // 删除下载请求
        GetExsitData(continueData.url);
        // 储存下载配置数据
        SaveCurrentData();
        // 发送下载成功回调
        if (pRequireData.pSucess != null)
        {
            ActionManager.Add(() =>
            {
                //Debug.LogError("Download successed! url:" + continueData.url);
                pRequireData.pSucess(continueData.cacheFilePath);
                return true;
            });
        }
    }

    public static void CheckDirExist(string pPath)
    {
        string direName = Path.GetDirectoryName(pPath);
        //如果不存在保存文件夹路径，新建文件夹
        if (!Directory.Exists(direName))
        {
            Directory.CreateDirectory(direName);
        }
    }

    /// <summary>
    /// 辅助函数，从URL获取下载的文件名字
    /// </summary>
    /// <param name="url"></param>
    /// <returns></returns>
    public static string GetFileNameFromUrl(string url)
    {
        int lastIndex = url.LastIndexOf('/');
        if (url.Contains("?"))
        {
            string lastEndUrl = url.Substring(lastIndex, url.Length - lastIndex);

            int tempIndex = lastEndUrl.LastIndexOf('?');
            string result = lastEndUrl.Substring(1, tempIndex - 1);
            return result;
        }
        return url.Substring(lastIndex, url.Length - lastIndex);
    }

    private long GetFileContentLength(string url)
    {
        HttpWebRequest request = null;
        try
        {
            ServicePointManager.ServerCertificateValidationCallback = MyRemoteCertificateValidationCallback;

            request = (HttpWebRequest)HttpWebRequest.Create(url);
            request.Timeout = TimeOutWait;
            request.ReadWriteTimeout = ReadWriteTimeOut;
            //向服务器请求，获得服务器回应数据流
            WebResponse respone = request.GetResponse();
            request.Abort();
            return respone.ContentLength;
        }
        catch (Exception e)
        {
            Debug.LogError("##########" + e.Message);

            if (request != null)
                request.Abort();
            return 0;
        }
    }
    public bool MyRemoteCertificateValidationCallback(System.Object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
    {
        bool isOk = true;
        // If there are errors in the certificate chain,
        // look at each error to determine the cause.
        if (sslPolicyErrors != SslPolicyErrors.None)
        {
            for (int i = 0; i < chain.ChainStatus.Length; i++)
            {
                if (chain.ChainStatus[i].Status == X509ChainStatusFlags.RevocationStatusUnknown)
                {
                    continue;
                }
                chain.ChainPolicy.RevocationFlag = X509RevocationFlag.EntireChain;
                chain.ChainPolicy.RevocationMode = X509RevocationMode.Online;
                chain.ChainPolicy.UrlRetrievalTimeout = new TimeSpan(0, 1, 0);
                chain.ChainPolicy.VerificationFlags = X509VerificationFlags.AllFlags;
                bool chainIsValid = chain.Build((X509Certificate2)certificate);
                if (!chainIsValid)
                {
                    isOk = false;
                    break;
                }
            }
        }
        return isOk;
    }


    private ContinueDownloadData GetExsitData(string pUrl)
    {
        for (int i = 0; i < DownloadConfig.datas.Count; ++i)
        {
            if (DownloadConfig.datas[i].url.Equals(pUrl))
            {
                ContinueDownloadData result = DownloadConfig.datas[i];
                DownloadConfig.datas.RemoveAt(i);
                return result;
            }
        }
        return null;
    }

}

[Serializable, ProtoContract]
public class ContinueDownloadCacheConfig
{
    [ProtoMember(1)]
    public List<ContinueDownloadData> datas;
}

[Serializable, ProtoContract]
public class ContinueDownloadData
{
    [ProtoMember(1)]
    public string url;
    [ProtoMember(2)]
    public string cacheFilePath;
    [ProtoMember(3)]
    public long byteLength;

    public ContinueDownloadData()
    {

    }

    public ContinueDownloadData(string url, long byteLength)
    {
        this.url = url;
        this.byteLength = byteLength;
        this.cacheFilePath = FileDownloadHelper.Instance.PersisitentDataPath + "/CacheDownload/" + FileDownloadHelper.GetFileNameFromUrl(url);
    }

}

public class GetUrlsSizeRequire
{
    public string[] urls;

    public FileDownloadHelper.RequestSucess pSuccess;
    public FileDownloadHelper.RequestFailed pFailed;
}

public class ContinueDownloadRequire
{
    public string url;
    public string hashMD5;
    public FileDownloadHelper.DownLoadUpdate pUpdate;
    public FileDownloadHelper.DownLoadSuccess pSucess;
    public FileDownloadHelper.DownloadFailed pFailed;
    public FileDownloadHelper.DownloadException pException;
}
