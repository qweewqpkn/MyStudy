﻿using System;
using System.IO;
using UnityEngine;

public class GlobalFunction
{
    public static readonly string LOCAL_RES_URL = "file://" + Application.persistentDataPath + "/";
    public static readonly string LOCAL_RES_PATH = Application.persistentDataPath + "/";
    public static readonly string LOCAL_APKRES_PATH = Application.persistentDataPath + "/APKClientRes/";

    //读取文件
    public static string LoadPersistentFile(string name)
    {
        return LoadPersistentFile(name, Application.persistentDataPath + "/LocalFiles/");
    }

    //读取文件
    public static string LoadPersistentFile(string name, string path)
    {
        string result = "";
        string t_path = path + name;
        Debug.Log("LoadPersistentFile = " + t_path);
        if (!string.IsNullOrEmpty(t_path) && File.Exists(t_path))
        {
            //使用流的形式读取
            StreamReader sr = null;
            try
            {
                sr = File.OpenText(t_path);
            }
            catch (Exception e)
            {
                //路径与名称未找到文件则直接返回空
                Debug.LogError("未找到文件" + e.Message);
                return "";
            }
            string line;
            string allLine = "";
            while ((line = sr.ReadLine()) != null)
            {
                allLine += line;
            }
            //关闭流
            sr.Close();
            //销毁流
            sr.Dispose();
            //CreatePersistentFile(path, name, allLine);
            return allLine;
        }
        else
        {
            Debug.Log("########### File Path Not Find:" + t_path);
        }
        return result;
    }

    public static string LoadPersistentFile2(string name, string path)
    {
        if (File.Exists(path + name))
        {
            StreamReader sr = null;
            try
            {
                sr = File.OpenText(path + name);
            }
            catch (Exception e)
            {
                return "";
            }
            string line;
            string allLine = "";
            while ((line = sr.ReadLine()) != null)
            {
                allLine += line;
            }
            sr.Close();
            sr.Dispose();
            return allLine;
        }
        return "";
    }

    public static void SaveFiles(string infos, string name, bool saveRightNow = false)
    {
        SaveFiles(infos, name, "/LocalFiles", saveRightNow);
    }

    public static void SaveFiles(string infos, string name, string folder, bool saveRightNow = false)
    {
        if (!saveRightNow)
        {
            ActionManager.Add(() =>
            {
                string floderPath = CreatePersistentFolder(Application.persistentDataPath, folder);
                CreatePersistentFile(floderPath, name, infos);
                return true;
            });
        }
        else
        {
            string floderPath = CreatePersistentFolder(Application.persistentDataPath, folder);
            CreatePersistentFile(floderPath, name, infos);
        }
    }

    //创建文件夹，并返回路径
    public static string CreatePersistentFolder(string path, string FolderName)
    {
        string FolderPath = path + FolderName;
        if (!Directory.Exists(FolderPath))
        {
            Directory.CreateDirectory(FolderPath);
        }
        return FolderPath;
    }

    //创建保存的文件
    public static void CreatePersistentFile(string path, string name, string info)
    {
        string saveKey = path + "/" + name;

        //文件流信息
        StreamWriter sw;
        FileInfo t = new FileInfo(path + "/" + name);
        if (!t.Exists)
        {
            Debug.Log("CreatePersistentFile = " + saveKey);
            //如果此文件不存在则创建
            sw = t.CreateText();
        }
        else
        {
            Debug.Log("Delete.Write.PersistentFile = " + saveKey);
            //删除原文件，重新写入
            File.Delete(t.FullName);
            //t.Delete();
            sw = t.CreateText();
        }
        //以行的形式写入信息
        sw.Write(info);
        //关闭流
        sw.Close();
        //销毁流
        sw.Dispose();
    }

    //计算文件的MD5签名
    public static string FileMd5(string filePath)
    {
        System.Text.StringBuilder sb = new System.Text.StringBuilder();

        if (File.Exists(filePath))
        {
            FileStream file = new FileStream(filePath, FileMode.Open);
            if (file != null)
            {
                System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create();
                byte[] hash = md5.ComputeHash(file);
                file.Close();

                for (int i = 0; i < hash.Length; i++)
                {
                    sb.Append(hash[i].ToString("X2"));
                }
            }
        }

        string sign = sb.ToString();
        return sign.ToLower();
    }
}

