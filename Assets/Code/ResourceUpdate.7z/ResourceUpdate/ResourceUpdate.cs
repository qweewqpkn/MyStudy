﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;
using UnityEngine.SceneManagement;

public class ResourceUpdate : MonoBehaviour {

    public Text b_tips_1;

    public Image b_box_1;
    public Text b_title;
    public Text b_content;
    public Button b_quxiao;
    public Button b_lijigengxin;

    public RectTransform b_bar;
    public Slider b_slider;
    public Text b_bar_desc;


    // Use this for initialization
    void Start () {
        //ResourceUpdatePanel.instance.t_script = this;

        ResoureUpdateProxy.instance.Start();

        b_quxiao.onClick.AddListener(OnClickQuXiao);
        b_lijigengxin.onClick.AddListener(OnClickQueRen);
    }
	
	// Update is called once per frame
	void Update () {
        ActionManager.Update();
    }

    void OnClickQuXiao()
    {
        if (_quxiao != null)
        {
            _quxiao(null);
        }

        //Debug.Log("########## SceneManager.LoadScene main");
        //SceneManager.LoadScene("main", LoadSceneMode.Single);
    }

    void OnClickQueRen()
    {
        if(_queren != null)
        {
            _queren(null);
        }
    }

    UnityAction<GameObject> _quxiao = null;
    public void SetQuXiaoAction(UnityAction<GameObject> quxiao)
    {
        _quxiao = quxiao;
    }

    UnityAction<GameObject> _queren = null;
    public void SetQuerenAction(UnityAction<GameObject> queren)
    {
        _queren = queren;
    }
}
