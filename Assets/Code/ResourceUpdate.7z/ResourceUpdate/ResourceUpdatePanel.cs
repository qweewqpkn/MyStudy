﻿using LuaInterface;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.SceneManagement;

public class ResourceUpdatePanel : Singleton<ResourceUpdatePanel>
{
    //public ResourceUpdate t_script = null;

    private LuaFunction update_finish_callback;
    private LuaFunction update_failed_callback;
    private LuaFunction update_info_callback;
    private LuaFunction update_bar_callback;
    private LuaFunction show_box_callback;
    private LuaFunction close_callback;
    private LuaFunction open_url_callback;

    public void SetFinishCallback(LuaFunction p_call)
    {
        update_finish_callback = p_call;
    }
    public void SetFailedCallback(LuaFunction p_call)
    {
        update_failed_callback = p_call;
    }
    public void SetInfoCallback(LuaFunction p_call)
    {
        update_info_callback = p_call;
    }
    public void SetBarCallback(LuaFunction p_call)
    {
        update_bar_callback = p_call;
    }
    public void SetShowBoxCallback(LuaFunction p_call)
    {
        show_box_callback = p_call;
    }
    public void SetCloseCallback(LuaFunction p_call)
    {
        close_callback = p_call;
    }
    public void SetOpenURLCallback(LuaFunction p_call)
    {
        open_url_callback = p_call;
    }

    /// <summary>
    /// 通知可以开始游戏了
    /// </summary>
    /// <param name="obj"></param>
    public void OnPanelResLoadComplete()
    {
        Debug.LogError("############通知可以开始游戏了");


        Debug.Log("########## SceneManager.LoadScene main");
        //SceneManager.LoadScene("main", LoadSceneMode.Single);

        if (ResoureUpdateProxy.instance.is_need_reload)
        {
            Debug.Log("{unity]###############有更新,重启lua状态机");
            PlatformWebManager.Instance.ReLoadOnUpdateSuccess();
        }

        if (update_finish_callback != null)
        {
            update_finish_callback.Call();
        }
    }

    // 下载失败
    public void OnPanelFailed(string text)
    {
        if (update_failed_callback != null)
        {
            update_failed_callback.Call(text);
        }
    }

    //资源动态更新显示接口
    public void ResoureUpdateText(string text)
    {
        Debug.Log("#####ResoureUpdateText = " + text);
        //t_script.b_bar_desc.text = text;
        if (update_info_callback != null)
        {
            update_info_callback.Call(text);
        }
    }
    //更新进度条
    public void ResoureUpdateBar(float p_value)
    {
        //t_script.b_slider.value = p_value;
        if (update_bar_callback != null)
        {
            update_bar_callback.Call(p_value);
        }
    }
    //更新版本号
    public void ResoureUpdateVersion(string localVersion, string serverVersion)
    {
        //t_script.b_bar_desc.text = "UpdateVersion:" + localVersion + "->" + serverVersion;
    }

    public void ShowWarning(string title, string text, string buttonOkName, string buttonSkipName, byte state, UnityAction<GameObject> ok, UnityAction<GameObject> cancle)
    {
        //t_script.b_title.text = title;
        //t_script.b_content.text = text;

        //t_script.SetQuerenAction(ok);
        //t_script.SetQuXiaoAction(cancle);

        //t_script.b_box_1.gameObject.SetActive(true);

        if (show_box_callback != null)
        {
            show_box_callback.Call(text);
        }
    }

    public void Close()
    {
        //t_script.b_bar.gameObject.SetActive(true);
        //t_script.b_box_1.gameObject.SetActive(false);

        if (close_callback != null)
        {
            close_callback.Call();
        }
    }

    public void OpenURL(string url)
    {
        if (open_url_callback != null)
        {
            open_url_callback.Call(url);
        }
    }
}
