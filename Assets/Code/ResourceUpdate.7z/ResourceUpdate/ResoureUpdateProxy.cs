﻿using ProtoBuf;
using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Xml;
using Assets.Game.System.Module.ResoureManager;
using System.Text.RegularExpressions;
using System.Reflection;

//本地资源
[Serializable, ProtoContract]
public class LocalVersion
{
    [ProtoMember(1)]
    public string localVersion;
    [ProtoMember(2)]
    public string resServer; // 资源服地址
    [ProtoMember(3)]
    public string platformServer; // 平台服地址
    [ProtoMember(4)]
    public string channel; // 渠道类型
}

//資源更新數據
[Serializable, ProtoContract]
public class VersionData
{
    [ProtoMember(1)]
    public string version;
    [ProtoMember(2)]
    public PatchData[] patchs;
}
[Serializable, ProtoContract]
public class PatchData
{
    [ProtoMember(1)]
    public string oldVersion;
    [ProtoMember(2)]
    public string newVersion;
    [ProtoMember(3)]
    public string patch;
    [ProtoMember(4)]
    public string hash;
    [ProtoMember(5)]
    public byte state;          //0 可以跳过的更新，1 必须更新
}

//需要使用新包的资源列表
[Serializable, ProtoContract]
public class UpdateRes
{
    [ProtoMember(1)]
    public string[] res;
}


public class ResoureUpdateProxy : Singleton<ResoureUpdateProxy>
{
    //private PlayMakerFSM loginFSM;
    public static readonly string UPDATE_FILE = "updateRes.xml";
    public static readonly string VERSION_FILE = "localVersion.xml";
    public static readonly string SERVER_VERSION_FILE = "lobby_version.xml";
    public static readonly string ANDROID_FILE = "StreamingAssets.xml";

    public LocalVersion ServerConfig
    {
        get
        {
            return localVersion;
        }
    }

    private LocalVersion localVersion;                  //本地版本信息
    private string localVersionText = null;             //本地版本信息文本
    private VersionData serverVersion;                  //服务器版本信息
    private bool isSaveLocalVersion = false;            //是否保存本地文件
    private bool resUpdateState;                        //资源更新检测状态 true 成功 false 失败
    private bool isUpdate;                              //是否有更新
    private string lobbyPath = "lobby/";                //资源子目录

    public static Dictionary<string, string> StreamingAssetsDic; //Android所有的资源文件
    private bool isCopyError;                          //是否有copy错误
    private bool isCopyComplete = true;                //copy是否完成
    private int curCount = 0;                          //当前copy的数量
    private int allCount = 0;                          //总copy数量
    private string cacheApkPath;                       //缓存的APK目录，按照完成后删除APK
    private float apkProgress;                         //apk的下载进度
    private const byte MAXCOPYNUM = 10;                //最大同时copy数量

    public bool ResUpdateState
    {
        get
        {
            return resUpdateState;
        }
        set
        {
            resUpdateState = value;

            if (!resUpdateState)
            {
                ResourceUpdatePanel.instance.OnPanelFailed("更新失败");
            }

            //更新失败，2秒后依然可以进入游戏
            //if (!resUpdateState)
            //{
            //    if (isCopyComplete)
            //    {
            //        UpdateAddRes();
            //        TimeInfoManager.instance.AddTimer(0.5f, () =>
            //        {
            //            //通知可以开始游戏了
            //            ResourceUpdatePanel.instance.OnPanelResLoadComplete();
            //        });
            //    }
            //}
        }
    }

    /// <summary>
    /// 是否需要重新加载.pb和.lua文件
    /// </summary>
    public bool is_need_reload = false;

    public string resServerUrl = "https://vxres.jiuyou99.com/res/ANDROID/lobby/";
    public string ResServerUrl
    {
        get
        {
            Debug.Log("[unity]########## Get ResServerUrl = " + resServerUrl);
            return resServerUrl;
        }
        set
        {
            Debug.Log("[unity]########## Set ResServerUrl = " + value);
            resServerUrl = value;
        }
    }

    /// <summary>
    /// 清理
    /// </summary>
    public void Dispose()
    {
        localVersion = null;
    }

    public void Start()
    {
        //loginFSM = GlobalFunction.GetLoginFsm();
        ResourceUpdatePanel.instance.ResoureUpdateBar(0f);

        ResourceUpdatePanel.instance.ResoureUpdateText("正在检查游戏版本");

        //ResourceUpdatePanel.instance.Init();
        isSaveLocalVersion = false;
        ResUpdateState = true;

#if UNITY_ANDROID && !UNITY_EDITOR
        TimeInfoManager.instance.AddTimer(0.5f,()=>
        {
            CheckVersion();
        });
        return;
#else
        CheckVersion();
#endif

    }

    //检查版本
    public void CheckVersion()
    {
        is_need_reload = false;

        ResourceUpdatePanel.instance.ResoureUpdateText("正在从资源中读取版本文件");

#if UNITY_ANDROID && !UNITY_EDITOR

        localVersion = null;

        //安卓不支持使用file.openRead的方式，换为3W
        ResourceLoader.Instance.StartCoroutine(LoadLocalVersion());
        //ResourceLoader.Instance.StartCoroutine(LoadStreamingAssets());
        ActionManager.Add(() =>
        {
            if (localVersion != null /*&& StreamingAssetsDic != null && StreamingAssetsDic.Count > 0*/)
            {
                CheckLocalVersion("-1");
                return true;
            }
            return false;
        });
        return;
#endif
        // 读取安装目录version
        localVersionText = GlobalFunction.LoadPersistentFile(VERSION_FILE, ResourcePath.Path(ResourcePath.ReLocatePath("xml/")));
        CheckLocalVersion(localVersionText);
    }

    private string GetAndroidPath(string path, string fileName)
    {
        string filePath = "jar:file://" + Application.dataPath + "!/assets/ClientRes/";
        return filePath + path + fileName;
    }

    //安卓用，读取本地版本文件
    private IEnumerator LoadLocalVersion()
    {
        //string url = ResourcePath.URI(ResourcePath.ReLocatePath("xml/"), VERSION_FILE);

        string url = GetAndroidPath(ResourcePath.ReLocatePath("xml/"), VERSION_FILE);

        //ResourceUpdatePanel.instance.ResoureUpdateText("LoadLocalVersion url= " + url);

        WWW www = new WWW(url);
        yield return www;
        if (string.IsNullOrEmpty(www.error) && !string.IsNullOrEmpty(www.text))
        {
            //Debug.LogError("[unity]####################### www.text = " + www.text);
            localVersion = new LocalVersion();
            ConvetStringToLocalVersion(www.text, ref localVersion);
        }
        else
        {
            ResourceUpdatePanel.instance.ResoureUpdateText("本地版本文件读取错误！" + www.error);
        }

        www.Dispose();
        www = null;
    }

    //安卓用，读取本地版本文件
    private IEnumerator LoadApkStreamingAssets()
    {
        WWW www = new WWW(ResourcePath.URI(ResourcePath.ReLocatePath("xml/"), ANDROID_FILE));
        yield return www;
        if (string.IsNullOrEmpty(www.error))
        {
            UpdateRes tempData = new UpdateRes();
            ConvetStringToUpdateRes(www.text, ref tempData);

            //XmlDocument docOut = new System.Xml.XmlDocument();
            //docOut.LoadXml(www.text);
            //object obj = docOut.SelectSingleNode("Object");
            //FightRecordProxy.instance.ConvetParamsToType(typeof(UpdateRes), ref obj);
            //UpdateRes tempData = obj as UpdateRes;

            if (tempData != null)
            {
                StreamingAssetsDic = new Dictionary<string, string>();
                for (int i = 0; i < tempData.res.Length; i++)
                {
                    StreamingAssetsDic[tempData.res[i]] = "1";
                }
            }
        }
        else
        {
            ResUpdateState = false;
            ResourceUpdatePanel.instance.ResoureUpdateText("本地版本StreamingAssets文件读取错误！");
        }

        www.Dispose();
        www = null;
    }

    //#if UNITY_ANDROID
    //安卓用，读取本地版本所有文件
    private IEnumerator LoadStreamingAssets()
    {
        WWW www = new WWW(ResourcePath.URI(ResourcePath.ReLocatePath("xml/"), ANDROID_FILE));
        yield return www;
        if (string.IsNullOrEmpty(www.error))
        {

#if UNITY_ANDROID && !UNITY_EDITOR
            //如果在原目录找到了本地版本文件则清除之前缓存的本地文件
            if (Directory.Exists(GlobalFunction.LOCAL_APKRES_PATH))
            {
                DeleteDirectory(GlobalFunction.LOCAL_APKRES_PATH);
            }
#endif

            UpdateRes tempData = new UpdateRes();
            ConvetStringToUpdateRes(www.text, ref tempData);

            //XmlDocument docOut = new System.Xml.XmlDocument();
            //docOut.LoadXml(www.text);
            //object obj = docOut.SelectSingleNode("Object");
            //FightRecordProxy.instance.ConvetParamsToType(typeof(UpdateRes), ref obj);
            //UpdateRes tempData = obj as UpdateRes;
            if (tempData != null)
            {
                StreamingAssetsDic = new Dictionary<string, string>();
                for (int i = 0; i < tempData.res.Length; i++)
                {
                    StreamingAssetsDic[tempData.res[i]] = "1";
                }
            }
            //测试
            //CopyApkClientRes(GlobalFunction.LOCAL_APKRES_PATH);
        }
        else
        {
            ResourcePath.isReadPersistentData = true;
            ResourceLoader.Instance.StartCoroutine(LoadApkStreamingAssets());
        }

        www.Dispose();
        www = null;
    }
    //#endif

    //检测本地版本信息
    private void CheckLocalVersion(string localVersionText)
    {
        //ResourceUpdatePanel.instance.ResoureUpdateText("localVersionText = " + localVersionText);
        Debug.Log("[unity]################ localVersionText = " + localVersionText);

        //如果没有从缓存目录中查询到，则读取本地配置文件的版本号
        if (string.IsNullOrEmpty(localVersionText))
        {
            ResUpdateState = false;
            ResourceUpdatePanel.instance.ResoureUpdateText("本地版本文件加载错误！");
            return;
        }
        else
        {
            if (localVersion == null)
            {
                Debug.Log("[unity]################ localVersion = null");
                localVersion = new LocalVersion();
                ConvetStringToLocalVersion(localVersionText, ref localVersion);
            }
        }

        //根据版本号，检测是否安装了新的应用，如果安装了则清理数据
        string installInfo = PlayerPrefs.GetString("AppInstallVersion");
        if (installInfo != localVersion.localVersion)
        {
            //清理数据
            string key = Application.persistentDataPath + "/ClientRes/" + VERSION_FILE;
            key = key.Replace('/', '1');
            if (PlayerPrefs.HasKey(key))
            {
                PlayerPrefs.DeleteKey(key);
            }
            PlayerPrefs.SetString("AppInstallVersion", localVersion.localVersion);
            PlayerPrefs.Save();
        }


        //友盟启动，这里才有渠道参数
        string channel = "";
        if (localVersion != null)
        {
            channel = localVersion.channel;
        }
        if (string.IsNullOrEmpty(channel))
        {
            channel = "0";
        }

        //檢測沙盒緩存目錄是否有版本文件
        string tempText = GlobalFunction.LoadPersistentFile(VERSION_FILE, Application.persistentDataPath + "/ClientRes/");
        ResourceUpdatePanel.instance.ResoureUpdateText("正在从缓存中读取版本文件");
        //Debug.LogError("LoadCache Version tempText=" + tempText);
        //NGUIDebug.Log("缓存中读取版本文件: " + tempText);

        if (!string.IsNullOrEmpty(tempText))
        {
            LocalVersion tempLocal = new LocalVersion();
            ConvetStringToLocalVersion(tempText, ref tempLocal);

            if (ResourcePath.isReadPersistentData)
            {
                cacheApkPath = GlobalFunction.LoadPersistentFile("ApkInstallInfo");

                Debug.LogError("isReadPersistentData true " + "tempLocal " + tempLocal.localVersion + " localVersion " + localVersion.localVersion + " cacheApkPath " + cacheApkPath);
                if (tempLocal.localVersion != localVersion.localVersion)
                {
                    if (!string.IsNullOrEmpty(cacheApkPath))
                    {
                        isSaveLocalVersion = true;
                        tempLocal.localVersion = localVersion.localVersion;

                        if (File.Exists(cacheApkPath))
                        {
                            File.Delete(cacheApkPath);
                        }

                        GlobalFunction.SaveFiles("", "ApkInstallInfo");
                    }
                }
            }

            //版本號轉化為數字
            Int64 resVersion = 0;
            Int64 cacheVersion = 0;
            Regex reg = new Regex(@"[\d]+");
            if (!string.IsNullOrEmpty(localVersion.localVersion))
            {
                string versionNum = "";
                MatchCollection mat = reg.Matches(localVersion.localVersion);
                if (mat != null)
                {
                    int count = mat.Count;
                    for (int i = 0; i < count; i++)
                    {
                        Match item = mat[i];
                        versionNum += item.Value;
                    }
                    Int64.TryParse(versionNum, out resVersion);
                }
            }
            if (!string.IsNullOrEmpty(tempLocal.localVersion))
            {
                string versionNum = "";
                MatchCollection mat = reg.Matches(tempLocal.localVersion);
                if (mat != null)
                {
                    int count = mat.Count;
                    for (int i = 0; i < count; i++)
                    {
                        Match item = mat[i];
                        versionNum += item.Value;
                    }
                    Int64.TryParse(versionNum, out cacheVersion);
                }
            }

            //對比本地資源版本，看是否需要清理緩存文件夾，覆盖安装的时候
            if (resVersion != 0 && cacheVersion != 0)
            {
                if (resVersion > cacheVersion)//重装包
                {
                    //Debug.LogError("[unity]############## 重装包 resVersion=" + resVersion.ToString() + "cacheVersion=" + cacheVersion.ToString());

                    isSaveLocalVersion = true;
                    tempLocal.localVersion = localVersion.localVersion;

                    //NGUIDebug.Log("正在清理緩存1: ");

                    ResourceUpdatePanel.instance.ResoureUpdateText("正在清理缓存...");
                    //Debug.LogError("[unity]############## DeleteDirectory 111 Application.persistentDataPath ClientRes");
                    //DeleteDirectory(Application.persistentDataPath + "/ClientRes/");
                    GlobalFunction.SaveFiles("", UPDATE_FILE, "/ClientRes");
                    UpdateSplitRes();

                    // TODO 删除小游戏
                    /*
                    ResourceUpdatePanel.instance.ResoureUpdateText("正在清理缓存...");
                    DeleteDirectory(Application.persistentDataPath + "/SplitRes/ClientRes/StandaloneWindows/assetbundle/dou_di_zhu");
                    GlobalFunction.SaveFiles("", UPDATE_FILE, "/ClientRes");
                    UpdateSplitRes();
                    */

                    //清除缓存
                    Caching.CleanCache();
                    UnityEngine.Debug.LogWarning("正在清理緩存1...");
                }
            }

            tempLocal.resServer = localVersion.resServer;
            localVersion = tempLocal;
        }
        else
        {
            //新包，和上面流程一样
            ResourceUpdatePanel.instance.ResoureUpdateText("正在清理緩存...");
            //Debug.LogError("[unity]############## DeleteDirectory 222 Application.persistentDataPath ClientRes");
            //DeleteDirectory(Application.persistentDataPath + "/ClientRes/");
            GlobalFunction.SaveFiles("", UPDATE_FILE, "/ClientRes");
            UpdateSplitRes();

            //清除缓存
            Caching.CleanCache();
            UnityEngine.Debug.LogWarning("正在清理緩存2...");
            isSaveLocalVersion = true;
        }

        if (localVersion == null)
        {
            ResUpdateState = false;
            ResourceUpdatePanel.instance.ResoureUpdateText("本地版本文件解析出错");
            return;
        }

        if (isSaveLocalVersion)
        {
            //保存版本号
            SaveFile(localVersion, VERSION_FILE, "/ClientRes");
        }

        //资源服如果为空，则跳过更新检测
        if (string.IsNullOrEmpty(ResServerUrl))
        {
            ResourceUpdatePanel.instance.ResoureUpdateVersion(localVersion == null ? "未知" : localVersion.localVersion, serverVersion == null ? "未知" : serverVersion.version);
            ResourceUpdatePanel.instance.ResoureUpdateText("资源服地址不存在，跳过更新检测");
            ResUpdateState = false;
            return;
        }

        //读取资源服务器版本文件
        ResourceLoader.Instance.StartCoroutine(LoadResServerVersion());
    }

    //获取服务器版本文件
    private IEnumerator LoadResServerVersion()
    {
        if (localVersion != null)
        {
            ResourceUpdatePanel.instance.ResoureUpdateText("正在读取服务器版本号...");
            long timestamp = (long)(System.DateTime.Now - TimeZone.CurrentTimeZone.ToLocalTime(new System.DateTime(1970, 1, 1))).TotalSeconds;
            WWW www = new WWW(ResServerUrl + "xml/" + SERVER_VERSION_FILE + "?timestamp=" + timestamp);
            yield return www;

            if (string.IsNullOrEmpty(www.error) && !string.IsNullOrEmpty(www.text))
            {
                try
                {
                    serverVersion = new VersionData();
                    ConvetStringToVersionData(www.text, ref serverVersion);
                }
                catch (Exception)
                {
                    ResourceUpdatePanel.instance.ResoureUpdateText("资源服务器版本文件解析失败！");
                }

                if (serverVersion == null)
                {
                    ResUpdateState = false;
                    ResourceUpdatePanel.instance.ResoureUpdateText("资源服务器版本文件解析失败！");
                }
            }
            else
            {
                ResUpdateState = false;
                ResourceUpdatePanel.instance.ResoureUpdateText("资源服务器版本文件读取失败！");
            }

            www.Dispose();
            www = null;
        }

        ResourceUpdatePanel.instance.ResoureUpdateVersion(localVersion == null ? "未知" : localVersion.localVersion, serverVersion == null ? "未知" : serverVersion.version);
        if (serverVersion != null)
        {
            CheckUpdate();           
        }
    }

    //检查更新
    private void CheckUpdate()
    {
        if (localVersion != null && serverVersion != null)
        {
            Debug.LogError("[unity]############## localVersion=" + localVersion.localVersion);
            Debug.LogError("[unity]############## serverVersion=" + serverVersion.version);
            if (localVersion.localVersion.Equals(serverVersion.version))
            {
                Debug.LogError("[unity]############## 版本一致");
                ResUpdateState = true;
                ResourceUpdatePanel.instance.ResoureUpdateText("已是最新版本！");
                SaveLocalVersion();
            }
            else
            {
                Debug.LogError("[unity]############## 版本不同");
                //有更新的话，需要重新加载配置和lua文件
                is_need_reload = true;

                //查找可以更新的版本
                PatchData patch = CheckPath(localVersion.localVersion);
                if (patch == null)
                {
                    ResUpdateState = false;
                    ResourceUpdatePanel.instance.ResoureUpdateText("没有找到可用于更新的配置！");
                    //SaveLocalVersion();
                }
                else
                {
                    isUpdate = true;

                    if (string.IsNullOrEmpty(patch.patch) || !patch.patch.EndsWith(".zip"))
                    {
#if UNITY_ANDROID && !UNITY_EDITOR
                        if (patch.patch.StartsWith("http"))
                        {
                            string text2 = "版本差异过大，请重新下载游戏并安装！";
                            ResourceUpdatePanel.instance.ShowWarning("重新下载", text2, "下载", "", 1, (GameObject go) =>
                            {
                                //打开网页
                                if (patch != null && !string.IsNullOrEmpty(patch.patch))
                                {
                                    Application.OpenURL(patch.patch);
                                }
                            },
                            (GameObject go) =>
                            {

                            });
                        }
                        //else
                        //{
                        //    string[] urlsTemp = new string[1];
                        //    urlsTemp[0] = localVersion.resServer + patch.patch;
                        //    FileDownloadHelper.Instance.StartRequestAllFileLength(new GetUrlsSizeRequire()
                        //    {
                        //        urls = urlsTemp,
                        //        pSuccess = OnGetAllFileSizeSuccessaAPK, // 后续处理在这里
                        //        pFailed = OnGetAllFileSizeFailed
                        //    });
                        //}
#else
                        ResourceUpdatePanel.instance.OpenURL(patch.patch);

                        string text = "版本差异过大，请重新下载游戏并安装！";
                        ResourceUpdatePanel.instance.ShowWarning("重新下载", text, "下载", "", 1, (GameObject go) =>
                        {
                            //打开网页
                            if (patch != null && !string.IsNullOrEmpty(patch.patch))
                            {
                                Application.OpenURL(patch.patch);
                            }
                        },
                        (GameObject go) =>
                        {

                        });
#endif
                        return;
                    }

                    //检测是否是必须下载的更新包
                    if (patch.state == 1 || true)
                    {
                        string[] urlsTemp = new string[1];
                        urlsTemp[0] = ResServerUrl + patch.patch;
                        FileDownloadHelper.Instance.StartRequestAllFileLength(new GetUrlsSizeRequire()
                        {
                            urls = urlsTemp,
                            pSuccess = OnGetAllFileSizeSuccessIntegrant, // 后续处理在这里
                            pFailed = OnGetAllFileSizeFailed
                        });
                    }
                    else
                    {
                        //保存上一补丁的版本号
                        SaveFile(localVersion, VERSION_FILE, "/ClientRes");

                        if (Application.internetReachability == NetworkReachability.ReachableViaLocalAreaNetwork)
                        {
                            ResourceUpdatePanel.instance.ResoureUpdateText("正在下载补丁包 " + patch.newVersion);
                            DownLoadPatchHelper(patch);
                            //yield return DownLoadPatch(patch);
                        }
                        else
                        {
                            string[] urlsTemp = new string[1];
                            urlsTemp[0] = ResServerUrl + patch.patch;
                            FileDownloadHelper.Instance.StartRequestAllFileLength(new GetUrlsSizeRequire()
                            {
                                urls = urlsTemp,
                                pSuccess = OnGetAllFileSizeSuccess, // 后续处理在这里
                                pFailed = OnGetAllFileSizeFailed
                            });
                        }
                    }
                }
            }
        }
    }

    private void OnGetAllFileSizeSuccessIntegrant(long totalSize)
    {
        float downLoadSize = (float)(totalSize / 1024f) / 1024f;
        if (downLoadSize < 0.01f)
        {
            downLoadSize = 0.01f;
        }
        string text = "";
        if (Application.internetReachability == NetworkReachability.ReachableViaLocalAreaNetwork)
            text = string.Format("必须更新后才可进入游戏！\n资源包大小：{0:0.00}M", downLoadSize);
        else
            text = string.Format("必须更新后才可进入游戏！（当前非WIFI环境）\n资源包大小：{0:0.00}M", downLoadSize);

        //ResourceUpdatePanel.instance.ShowWarning("需要更新", text, "更新", "跳过", 1, (GameObject go) =>
        //{
        //    PatchData patch = CheckPath(localVersion.localVersion);
        //    if (patch != null)
        //    {
        //        ResourceUpdatePanel.instance.ResoureUpdateText("正在下载补丁包 " + patch.newVersion);
        //        DownLoadPatchHelper(patch);
        //    }
        //    ResourceUpdatePanel.instance.Close();
        //},
        //(GameObject go) =>
        //{
        //    ResUpdateState = false;
        //    ResourceUpdatePanel.instance.ResoureUpdateText("跳过更新！");
        //    ResourceUpdatePanel.instance.Close();
        //});

        //需求就是不加提示
        PatchData patch = CheckPath(localVersion.localVersion);
        if (patch != null)
        {
            ResourceUpdatePanel.instance.ResoureUpdateText("正在下载补丁包 " + patch.newVersion);
            DownLoadPatchHelper(patch);
        }
        ResourceUpdatePanel.instance.Close();
    }

    private void OnGetAllFileSizeSuccess(long totalSize)
    {
        float downLoadSize = (float)(totalSize / 1024f) / 1024f;
        if (downLoadSize < 0.01f)
        {
            downLoadSize = 0.01f;
        }
        string text = string.Format("当前非WIFI环境，确认要继续更新吗？\n资源包大小：{0:0.00}M", downLoadSize);
        ResourceUpdatePanel.instance.ShowWarning("需要更新", text, "更新", "跳过", 0, (GameObject go) =>
        {
            PatchData patch = CheckPath(localVersion.localVersion);
            if (patch != null)
            {
                ResourceUpdatePanel.instance.ResoureUpdateText("正在下载补丁包 " + patch.newVersion);
                DownLoadPatchHelper(patch);
            }
            ResourceUpdatePanel.instance.Close();
        },
        (GameObject go) =>
        {
            ResUpdateState = false;
            ResourceUpdatePanel.instance.ResoureUpdateText("跳过更新！");
            ResourceUpdatePanel.instance.Close();
        });

    }

    private void OnGetAllFileSizeFailed(int errorCode)
    {
        ResourceUpdatePanel.instance.ResoureUpdateText("获取更新包档大小失败：" + errorCode);
    }

    //查找可以更新的版本
    private PatchData CheckPath(string version)
    {
        if (serverVersion != null && serverVersion.patchs != null)
        {
            for (int i = 0; i < serverVersion.patchs.Length; i++)
            {
                if (serverVersion.patchs[i].oldVersion.Equals(version))
                {
                    return serverVersion.patchs[i];
                }
            }
        }

        return null;
    }

    //断线重连下载
    private void DownLoadPatchHelper(PatchData patch)
    {
        FileDownloadHelper.Instance.StartContinueDownload(new ContinueDownloadRequire()
        {
            url = ResServerUrl + patch.patch,
            pSucess = (filePath) =>
            {
                //校验Hash值
                if (!string.IsNullOrEmpty(patch.hash))
                {
                    string hash = GlobalFunction.FileMd5(filePath);
                    if (!hash.Equals(patch.hash))
                    {
                        ResourceUpdatePanel.instance.ResoureUpdateText("文件校验失败，请重新下载！");
                        return;
                    }
                }

                bool isExtract = false;
                // 解压文件
                try
                {
                    Zip zip = new Zip();
                    isExtract = zip.Extract(filePath, GlobalFunction.LOCAL_RES_PATH, 4096, true);
                }
                catch (Exception e)
                {
                    Debug.LogError(e.ToString());
                    isExtract = false;
                }

                if (!isExtract)
                {
                    ResUpdateState = false;
                    ResourceUpdatePanel.instance.ResoureUpdateText(patch.patch + " 解压失败！");
                }
                else
                {
                    //更新本地版本信息
                    localVersion.localVersion = patch.newVersion;
                    ResourceUpdatePanel.instance.ResoureUpdateVersion(localVersion == null ? "未知" : localVersion.localVersion, serverVersion == null ? "未知" : serverVersion.version);
                    SaveFile(localVersion, VERSION_FILE, "/ClientRes");
                    //调用一次资源释放
                    //System.GC.Collect();
                    //继续检测版本更新
                    CheckUpdate();
                }

            },
            pFailed = (pMsg) =>
            {
                ResUpdateState = false;
                ResourceUpdatePanel.instance.ResoureUpdateText(patch.patch + " 下载失败！");
            },
            pUpdate = (currentNum, totalNum, url) =>
            {
                float progress = (float)currentNum / (float)totalNum;
                ResourceUpdatePanel.instance.ResoureUpdateBar(progress);
            }
        });
    }

    //断线重连下载
    private void DownLoadApkHelper(PatchData patch)
    {
        FileDownloadHelper.Instance.StartContinueDownload(new ContinueDownloadRequire()
        {
            url = ResServerUrl + patch.patch,
            pSucess = (filePath) =>
            {
                //校验Hash值
                if (!string.IsNullOrEmpty(patch.hash))
                {
                    string hash = GlobalFunction.FileMd5(filePath);
                    if (!hash.Equals(patch.hash))
                    {
                        ResourceUpdatePanel.instance.ResoureUpdateText("文件校验失败，请重新下载！");
                        return;
                    }
                }

                cacheApkPath = filePath;
                Debug.LogError("File Path: " + cacheApkPath);

                GlobalFunction.SaveFiles(cacheApkPath,"ApkInstallInfo");

                //创建一个文件缓存安装信息
                //using (FileStream fs = new FileStream(GlobalFunction.LOCAL_APKRES_PATH + "/ApkInstallInfo", FileMode.Create))
                //{
                //    if (string.IsNullOrEmpty(cacheApkPath))
                //    {
                //        cacheApkPath = "";
                //    }

                //    byte[] b = Encoding.UTF8.GetBytes(cacheApkPath);
                //    fs.Write(b, 0, b.Length);
                //}

                //等待资源整理完成，才安装新的APK文件
                ActionManager.Add(() =>
                {
                    if (isCopyComplete)
                    {
                        Debug.LogError("File Path Start: " + filePath);
                        ResourceUpdatePanel.instance.ShowWarning("安装游戏", "您需要根据提示重新安装应用程序，请不要拒绝安装！", "安装", " ", 1, (GameObject go) =>
                        {
#if UNITY_ANDROID && !UNITY_EDITOR
                        //System.Platform.PlatformTool.instance.InstallApkAtPath(filePath);
#endif
                        },
                       (GameObject go) =>
                       {

                       });

#if UNITY_ANDROID  && !UNITY_EDITOR
                        //System.Platform.PlatformTool.instance.InstallApkAtPath(filePath);
#endif
                        return true;
                    }
                    return false;
                });
            },
            pFailed = (pMsg) =>
            {
                ResourceUpdatePanel.instance.ShowWarning("下载失败", "请检查网酪连接并重新尝试下载！", "重新下载", " ", 1, (GameObject go) =>
                 {
                     DownLoadApkHelper(patch);
                     ResourceUpdatePanel.instance.Close();
                 },
                (GameObject go) =>
                {

                });
            },
            pUpdate = (currentNum, totalNum, url) =>
            {
                if (!ResourcePath.isReadPersistentData)
                {
                    apkProgress = (float)currentNum / (float)totalNum / 2.0f;
					//Debug.LogError("pUpdate currentNum: " + currentNum + " totalNum: " + totalNum + " apkProgress " + apkProgress);
                    //如果资源已拷贝完成，还在进行下载APK则
                    if (isCopyComplete)
                    {
                        ResourceUpdatePanel.instance.ResoureUpdateText(string.Format("正在下载最新安装包，请耐心等候 {0:0}%", (0.5f + apkProgress) * 100));
                        ResourceUpdatePanel.instance.ResoureUpdateBar(0.5f + apkProgress);
                    }
                }
                else
                {
                    apkProgress = (float)currentNum / (float)totalNum;
					//Debug.LogError("pUpdate currentNum: " + currentNum + " totalNum: " + totalNum + " apkProgress " + apkProgress);
                    //如果资源已拷贝完成，还在进行下载APK则
                    if (isCopyComplete)
                    {
                        ResourceUpdatePanel.instance.ResoureUpdateText(string.Format("正在下载最新安装包，请耐心等候 {0:0}%", (apkProgress) * 100));
                        ResourceUpdatePanel.instance.ResoureUpdateBar(apkProgress);
                    }
                }
            },
            pException = (pMsg) =>
            {
                 //ResourceUpdatePanel.instance.ResoureUpdateText(string.Format("网络连接不稳定，正在尝试重新下载，请耐心等候 {0:0}%", (0.5f + apkProgress) * 100));
            },
        });
    }

    public void UpdateAddRes()
    {
        //检测分包资源是否存在
        if (!Directory.Exists(Application.persistentDataPath + "/ClientRes/"))
        {
            GlobalFunction.SaveFiles("", UPDATE_FILE, "/ClientRes");
        }
        else
        {
            string text = GlobalFunction.LoadPersistentFile(UPDATE_FILE, Application.persistentDataPath + "/ClientRes/");

            if (!string.IsNullOrEmpty(text))
            {
                UpdateRes tempData = new UpdateRes();
                ConvetStringToUpdateRes(text, ref tempData);

                //XmlDocument docOut = new System.Xml.XmlDocument();
                //docOut.LoadXml(text);
                //object obj = docOut.SelectSingleNode("Object");
                //FightRecordProxy.instance.ConvetParamsToType(typeof(UpdateRes), ref obj);
                //UpdateRes tempData = obj as UpdateRes;
                if (tempData != null)
                {
                    ResourcePath.m_updateRes = new Dictionary<string, string>();
                    for (int i = 0; i < tempData.res.Length; i++)
                    {
                        ResourcePath.m_updateRes[tempData.res[i]] = "1";
                    }
                }
            }
        }

        //检测分包资源是否存在
        if (!Directory.Exists(Application.persistentDataPath + "/SplitRes/"))
        {
            GlobalFunction.SaveFiles("", UPDATE_FILE, "/SplitRes");
        }
        else
        {
            string text = GlobalFunction.LoadPersistentFile(UPDATE_FILE, Application.persistentDataPath + "/SplitRes/");

            if (!string.IsNullOrEmpty(text))
            {
                UpdateRes tempData = new UpdateRes();
                ConvetStringToUpdateRes(text, ref tempData);

                //XmlDocument docOut = new System.Xml.XmlDocument();
                //docOut.LoadXml(text);
                //object obj = docOut.SelectSingleNode("Object");
                //FightRecordProxy.instance.ConvetParamsToType(typeof(UpdateRes), ref obj);
                //UpdateRes tempData = obj as UpdateRes;
                if (tempData != null)
                {
                    ResourcePath.m_SplitRes = new Dictionary<string, string>();
                    for (int i = 0; i < tempData.res.Length; i++)
                    {
                        ResourcePath.m_SplitRes[tempData.res[i]] = "1";
                    }
                }
            }
        }
    }
    //保存本地文件信息
    private void SaveLocalVersion()
    {
        //读取需要使用新包的资源列表
        if (!isUpdate)
        {
            UpdateAddRes();
        }
        else
        {
            //分包资源
            //if (File.Exists(Application.persistentDataPath + "/SplitRes/" + UPDATE_FILE))
            {
                string text = GlobalFunction.LoadPersistentFile(UPDATE_FILE, Application.persistentDataPath + "/SplitRes/");

                if (!string.IsNullOrEmpty(text))
                {
                    UpdateRes tempData = new UpdateRes();
                    ConvetStringToUpdateRes(text, ref tempData);

                    //XmlDocument docOut = new System.Xml.XmlDocument();
                    //docOut.LoadXml(text);
                    //object obj = docOut.SelectSingleNode("Object");
                    //FightRecordProxy.instance.ConvetParamsToType(typeof(UpdateRes), ref obj);
                    //UpdateRes tempData = obj as UpdateRes;
                    if (tempData != null)
                    {
                        ResourcePath.m_SplitRes = new Dictionary<string, string>();
                        for (int i = 0; i < tempData.res.Length; i++)
                        {
                            ResourcePath.m_SplitRes[tempData.res[i]] = "1";
                        }
                    }
                }
            }

            //查找所有目录，检测所有资源列表
            string path = Application.persistentDataPath + "/ClientRes/";

            if (Directory.Exists(path))
            {
                ResourcePath.m_updateRes = new Dictionary<string, string>();
                AllFile(path, ref ResourcePath.m_updateRes);

                UpdateRes tempData = new UpdateRes();
                tempData.res = ResourcePath.m_updateRes.Keys.ToArray();
                SaveFile(tempData, UPDATE_FILE, "/ClientRes");
                //清除缓存
                Caching.CleanCache();
            }
            else
            {
                ResUpdateState = false;
                ResourceUpdatePanel.instance.ResoureUpdateText("资源目录不存在，更新失败！");
                return;
            }
        }

        if (isUpdate)
        {
            Debug.Log("SaveFile " + VERSION_FILE);
            SaveFile(localVersion, VERSION_FILE, "/ClientRes");
        }

        if (ResUpdateState)
        {
            ResourceUpdatePanel.instance.ResoureUpdateText("正在读取游戏配置");
            //通知可以开始游戏了
            ResourceUpdatePanel.instance.OnPanelResLoadComplete();
        }
    }

    //读取分包里面的资源列表
    public void UpdateSplitRes(string customPath = "")
    {
        //查找所有目录，检测所有资源列表
        string path = "";
        if (string.IsNullOrEmpty(customPath))
        {
            path = Application.persistentDataPath + "/SplitRes/ClientRes/";
        }
        else
        {
            path = customPath;
        }

        if (Directory.Exists(path))
        {
            ResourcePath.m_SplitRes = new Dictionary<string, string>();
            AllFile(path, ref ResourcePath.m_SplitRes);

            UpdateRes tempData = new UpdateRes();
            tempData.res = ResourcePath.m_SplitRes.Keys.ToArray();
            SaveFile(tempData, UPDATE_FILE, "/SplitRes");
        }

    }

    //更新Android StreamingAssets目录下的资源列表
    public static void UpdateStreamingAssets()
    {
        //查找所有目录，检测所有资源列表
        string path = Application.dataPath + "/StreamingAssets/ClientRes/";

        if (Directory.Exists(path))
        {
            Dictionary<string, string> data = new Dictionary<string, string>();
            AllFile(path, ref data);

            UpdateRes tempData = new UpdateRes();
            tempData.res = data.Keys.ToArray();
            SaveFileImmeditely(tempData, "", "", true);
        }
    }

    //递归获得所有文件
    public static void AllFile(string path, ref Dictionary<string, string> list)
    {
        DirectoryInfo folder = new DirectoryInfo(path);
        FileInfo[] fi = folder.GetFiles("*.*");
        int count = fi.Length;
        string season = "";
        //是否是赛季资源
        if (path.Contains("season_"))
        {
            season = path.Substring(path.IndexOf("season_")) + "/";
        }
        for (int i = 0; i < count; i++)
        {
            FileInfo item = fi[i];
            list[season + item.Name] = "1";
        }  

        // TODO 添加上一层目录 解决资源同名问题

        DirectoryInfo[] infos = folder.GetDirectories();
        if (infos != null)
        {
            for (int i = 0; i < infos.Length; i++)
            {
                AllFile(path + "/" + infos[i].Name, ref list);
            }
        }

    }

    /// <summary>
    /// 删除指定目录，并更新资源文件
    /// </summary>
    /// <param name="file_path"></param>
    public static void DeleteFile(string file_path)
    {
        DeleteDirectory(file_path);
    }

    /// <summary>
    /// 更新资源XML
    /// </summary>
    public static void UpdateResXml()
    {
        //查找所有目录，检测所有资源列表
        string path = Application.persistentDataPath + "/ClientRes/";
        if (Directory.Exists(path))
        {
            ResourcePath.m_updateRes = new Dictionary<string, string>();
            AllFile(path, ref ResourcePath.m_updateRes);

            UpdateRes tempData = new UpdateRes();
            tempData.res = ResourcePath.m_updateRes.Keys.ToArray();
            SaveFile(tempData, UPDATE_FILE, "/ClientRes");
        }
    }

    /// <summary>
    /// 打包专用
    /// </summary>
    /// <param name="objSource"></param>
    /// <param name="fileName"></param>
    /// <param name="folder"></param>
    /// <param name="isDataPath"></param>
    private static void SaveFileImmeditely(object objSource, string fileName, string folder, bool isDataPath = false)
    {
        if (objSource != null)
        {
            XmlDocument xmlDoc = new XmlDocument();

            //创建XML根节点
            string funcXml = @"<NetCall name='" + objSource.ToString() + "'></NetCall>";
            xmlDoc.LoadXml(funcXml);

            XmlNode xmlNode = xmlDoc.SelectSingleNode("./NetCall");

            object obj = (object)objSource;

            //序列化对象实例至XML节点
            ConvetParamsToXmlForCPlus(ref obj, ref xmlNode, obj.GetType().FullName);

            //替换XML文档的根节点
            if (xmlNode.FirstChild != null)
            {
                xmlNode.ParentNode.ReplaceChild(xmlNode.FirstChild.Clone(), xmlNode);
                xmlNode = xmlDoc.FirstChild;
                XmlAttribute attr = xmlNode.Attributes["name"];
                if (attr != null)
                {
                    xmlNode.Attributes.Remove(attr);
                }

                Serialize.AddAttribute(xmlNode, "name", obj.ToString());
            }

            //保存本地信息
            if (xmlDoc != null)
            {
                if (!isDataPath)
                {
                    GlobalFunction.SaveFiles(xmlDoc.InnerXml, fileName, folder);
                }
                else
                {
                    StreamWriter sw;
                    FileInfo t = new FileInfo(Application.dataPath + "/StreamingAssets/ClientRes/Android/xml/" + ANDROID_FILE);
                    if (!t.Exists)
                    {
                        //如果此文件不存在则创建
                        sw = t.CreateText();
                    }
                    else
                    {
                        //删除原文件，重新写入
                        File.Delete(t.FullName);
                        //t.Delete();
                        sw = t.CreateText();
                    }
                    //以行的形式写入信息
                    sw.Write(xmlDoc.InnerXml);
                    //关闭流
                    sw.Close();
                    //销毁流
                    sw.Dispose();
                }

            }
        }
    }

    //保存文本
    public static void SaveFile(object objSource, string fileName, string folder, bool isDataPath = false)
    {
        if (objSource != null)
        {
            XmlDocument xmlDoc = new XmlDocument();

            //創建XML根節點
            string funcXml = @"<NetCall name='" + objSource.ToString() + "'></NetCall>";
            xmlDoc.LoadXml(funcXml);

            XmlNode xmlNode = xmlDoc.SelectSingleNode("./NetCall");

            object obj = (object)objSource;

            //序列化對象實例至XML節點
            ConvetParamsToXmlForCPlus(ref obj, ref xmlNode, obj.GetType().FullName);

            //替換XML文檔的根節點
            if (xmlNode.FirstChild != null)
            {
                xmlNode.ParentNode.ReplaceChild(xmlNode.FirstChild.Clone(), xmlNode);
                xmlNode = xmlDoc.FirstChild;
                XmlAttribute attr = xmlNode.Attributes["name"];
                if (attr != null)
                {
                    xmlNode.Attributes.Remove(attr);
                }

                Serialize.AddAttribute(xmlNode, "name", obj.ToString());
            }

            //保存本地信息
            if (xmlDoc != null)
            {
                if (!isDataPath)
                {
                    GlobalFunction.SaveFiles(xmlDoc.InnerXml, fileName, folder);
                }
                else
                {
                    StreamWriter sw;
                    FileInfo t = new FileInfo(Application.dataPath + "/StreamingAssets/ClientRes/Android/xml/" + ANDROID_FILE);
                    if (!t.Exists)
                    {
                        //如果此文件不存在则创建
                        sw = t.CreateText();
                    }
                    else
                    {
                        //删除原文件，重新写入
                        File.Delete(t.FullName);
                        //t.Delete();
                        sw = t.CreateText();
                    }
                    //以行的形式写入信息
                    sw.Write(xmlDoc.InnerXml);
                    //关闭流
                    sw.Close();
                    //销毁流
                    sw.Dispose();
                }

            }
        }
        //ResourcePackThread.instance.Add(() =>
        //{

        //    return true;
        //});
    }

    //将字符串转化为 LocalVersion
    public static void ConvetStringToLocalVersion(string info, ref LocalVersion sourceObj)
    {
        int indexL = 0;
        int indexR = 0;
        string key = "localVersion\">";
        indexL = info.IndexOf(key, indexL);
        if (indexL == -1)
        {
            return;
        }
        indexL += key.Length;
        indexR = info.IndexOf("<", indexL);
        if (indexR == -1)
        {
            return;
        }
        sourceObj.localVersion = info.Substring(indexL, indexR - indexL);
        indexL = indexR;

        key = "resServer\">";
        indexL = info.IndexOf(key, indexL);
        if (indexL == -1)
        {
            return;
        }
        indexL += key.Length;
        indexR = info.IndexOf("<", indexL);
        if (indexR == -1)
        {
            return;
        }
        sourceObj.resServer = info.Substring(indexL, indexR - indexL);
        indexL = indexR;

        key = "platformServer\">";
        indexL = info.IndexOf(key, indexL);
        if (indexL == -1)
        {
            return;
        }
        indexL += key.Length;
        indexR = info.IndexOf("<", indexL);
        if (indexR == -1)
        {
            return;
        }
        sourceObj.platformServer = info.Substring(indexL, indexR - indexL);
        indexL = indexR;

        key = "channel\">";
        indexL = info.IndexOf(key, indexL);
        if (indexL == -1)
        {
            return;
        }
        indexL += key.Length;
        indexR = info.IndexOf("<", indexL);
        if (indexR == -1)
        {
            return;
        }
        sourceObj.channel = info.Substring(indexL, indexR - indexL);
        indexL = indexR;
    }

    //将字符串转化为 UpdateRes
    private static void ConvetStringToUpdateRes(string info, ref UpdateRes sourceObj)
    {
        int indexL = 0;
        int indexR = 0;
        string key = "";
        List<string> patchDataList = new List<string>();
        int patchDataIndex = -1;
        string value = "";
        key = "\"\">";
        while (true)
        {
            patchDataIndex = info.IndexOf(key, indexL);
            if (patchDataIndex == -1)
            {
                break;
            }

            indexL = info.IndexOf(key, indexL);
            if (indexL == -1)
            {
                break;
            }

            indexL += 3;
            indexR = info.IndexOf("<", indexL);
            if (indexR == -1)
            {
                break;
            }
            value = info.Substring(indexL, indexR - indexL);
            indexL = indexR;

            patchDataList.Add(value);
        }

        sourceObj.res = patchDataList.ToArray();
        patchDataList.Clear();
        patchDataList = null;

        //Regex reg = new Regex("(?<=>).*?(?=<)");
        //MatchCollection mat = reg.Matches(info);
        //if (mat != null)
        //{
        //    string text = "";
        //    List<String> resList = new List<string>();
        //    int count = mat.Count;
        //    for (int i = 0; i < count; i++)
        //    {
        //        text = mat[i].Value;
        //        if (!string.IsNullOrEmpty(text))
        //        {
        //            resList.Add(text);
        //        }
        //    }

        //    sourceObj.res = resList.ToArray();
        //    resList.Clear();
        //    resList = null;
        //}

    }

    //将字符串转化为 VersionData
    public static void ConvetStringToVersionData(string info, ref VersionData sourceObj)
    {
        int indexL = 0;
        int indexR = 0;
        string key = "\"version\">";
        indexL = info.IndexOf(key, indexL);
        indexL += key.Length;
        indexR = info.IndexOf("<", indexL);
        sourceObj.version = info.Substring(indexL, indexR - indexL);
        indexL = indexR;

        List<PatchData> patchDataList = new List<PatchData>();
        PatchData tempData = null;
        int patchDataIndex = -1;

        while (true)
        {
            key = "PatchData\">";
            patchDataIndex = info.IndexOf(key, indexL);
            if (patchDataIndex == -1)
            {
                break;
            }

            tempData = new PatchData();

            key = "oldVersion\">";
            indexL = info.IndexOf(key, indexL);
            if (indexL == -1)
            {
                break;
            }
            indexL += key.Length;
            indexR = info.IndexOf("<", indexL);
            if (indexR == -1)
            {
                break;
            }
            tempData.oldVersion = info.Substring(indexL, indexR - indexL);
            indexL = indexR;

            key = "newVersion\">";
            indexL = info.IndexOf(key, indexL);
            if (indexL == -1)
            {
                break;
            }
            indexL += key.Length;
            indexR = info.IndexOf("<", indexL);
            if (indexR == -1)
            {
                break;
            }
            tempData.newVersion = info.Substring(indexL, indexR - indexL);
            indexL = indexR;

            key = "patch\">";
            indexL = info.IndexOf(key, indexL);
            if (indexL == -1)
            {
                break;
            }
            indexL += key.Length;
            indexR = info.IndexOf("<", indexL);
            if (indexR == -1)
            {
                break;
            }
            tempData.patch = info.Substring(indexL, indexR - indexL);
            indexL = indexR;

            key = "hash\">";
            indexL = info.IndexOf(key, indexL);
            if (indexL == -1)
            {
                break;
            }
            indexL += key.Length;
            indexR = info.IndexOf("<", indexL);
            if (indexR == -1)
            {
                break;
            }
            tempData.hash = info.Substring(indexL, indexR - indexL);
            indexL = indexR;

            key = "state\">";
            indexL = info.IndexOf(key, indexL);
            if (indexL == -1)
            {
                break;
            }
            indexL += key.Length;
            indexR = info.IndexOf("<", indexL);
            if (indexR == -1)
            {
                break;
            }
            string value = info.Substring(indexL, indexR - indexL);
            Byte.TryParse(value, out tempData.state);
            indexL = indexR;

            patchDataList.Add(tempData);
        }

        sourceObj.patchs = patchDataList.ToArray();
        patchDataList.Clear();
        patchDataList = null;
    }

    public static void DeleteDirectory(string DirectoryPath)
    {
        DirectoryInfo dir = new DirectoryInfo(DirectoryPath);
        if (dir != null && dir.Exists)
        {
            //文件夹
            try
            {
                DirectoryInfo[] directoryInfos = dir.GetDirectories();
                if (directoryInfos != null)
                {
                    int count = directoryInfos.Length;
                    for (int i = 0; i < count; i++)
                    {
                        DirectoryInfo dChild = directoryInfos[i];
                        if (dChild.Exists)
                        {
                            dChild.Delete(true);
                        }
                    }
                }
                dir.Delete(true);
            }
            catch (Exception e)
            {
                Debug.LogError("DeleteDirectory Error: " + e.ToString()); ;
            }
            
        }
    }

    //序列化到Xml
    public static bool ConvetParamsToXmlForCPlus(ref System.Object objType, ref XmlNode parent, string name)
    {
        XmlNode node;
        if (parent == null || objType == null)
        {
            // Debug.LogError("Unknown params infos in :" + type.Name);
            return false;
        }

        switch (Type.GetTypeCode(objType.GetType()))
        {
            case TypeCode.Boolean:
                {
                    node = parent.OwnerDocument.CreateNode(XmlNodeType.Element, "BOOL", "");

                    string strValue = Convert.ToString(objType);
                    if (node.Value == null)
                    {
                        node.InnerText = strValue;
                    }
                    else
                    {
                        node.Value = strValue;
                    }

                    XmlAttribute attr = node.OwnerDocument.CreateAttribute("name");
                    attr.Value = objType.GetType().Name;
                    node.Attributes.Append(attr);

                    parent.AppendChild(node);
                }
                break;

            case TypeCode.Char:
                {
                    node = parent.OwnerDocument.CreateNode(XmlNodeType.Element, "Char", "");

                    string strValue = Convert.ToString(objType);
                    if (node.Value == null)
                    {
                        node.InnerText = strValue;
                    }
                    else
                    {
                        node.Value = strValue;
                    }

                    XmlAttribute attr = node.OwnerDocument.CreateAttribute("name");
                    attr.Value = name;
                    node.Attributes.Append(attr);

                    parent.AppendChild(node);
                }
                break;

            case TypeCode.Byte:
                {
                    node = parent.OwnerDocument.CreateNode(XmlNodeType.Element, "Byte", "");

                    string strValue = Convert.ToString(objType);
                    if (node.Value == null)
                    {
                        node.InnerText = strValue;
                    }
                    else
                    {
                        node.Value = strValue;
                    }

                    XmlAttribute attr = node.OwnerDocument.CreateAttribute("name");
                    attr.Value = name;
                    node.Attributes.Append(attr);

                    parent.AppendChild(node);
                }
                break;

            case TypeCode.Int16:
                {
                    node = parent.OwnerDocument.CreateNode(XmlNodeType.Element, "Int16", "");

                    string strValue = Convert.ToString(objType);
                    if (node.Value == null)
                    {
                        node.InnerText = strValue;
                    }
                    else
                    {
                        node.Value = strValue;
                    }

                    XmlAttribute attr = node.OwnerDocument.CreateAttribute("name");
                    attr.Value = name;
                    node.Attributes.Append(attr);

                    parent.AppendChild(node);
                }
                break;

            case TypeCode.UInt16:
                {
                    node = parent.OwnerDocument.CreateNode(XmlNodeType.Element, "UInt16", "");

                    string strValue = Convert.ToString(objType);
                    if (node.Value == null)
                    {
                        node.InnerText = strValue;
                    }
                    else
                    {
                        node.Value = strValue;
                    }

                    XmlAttribute attr = node.OwnerDocument.CreateAttribute("name");
                    attr.Value = name;
                    node.Attributes.Append(attr);

                    parent.AppendChild(node);
                }
                break;

            case TypeCode.Int32:
                {
                    node = parent.OwnerDocument.CreateNode(XmlNodeType.Element, "Int32", "");

                    string strValue = Convert.ToString(objType);
                    if (node.Value == null)
                    {
                        node.InnerText = strValue;
                    }
                    else
                    {
                        node.Value = strValue;
                    }

                    XmlAttribute attr = node.OwnerDocument.CreateAttribute("name");
                    attr.Value = name;
                    node.Attributes.Append(attr);

                    parent.AppendChild(node);
                }
                break;

            case TypeCode.UInt32:
                {
                    node = parent.OwnerDocument.CreateNode(XmlNodeType.Element, "UInt32", "");

                    string strValue = Convert.ToString(objType);
                    if (node.Value == null)
                    {
                        node.InnerText = strValue;
                    }
                    else
                    {
                        node.Value = strValue;
                    }

                    XmlAttribute attr = node.OwnerDocument.CreateAttribute("name");
                    attr.Value = name;
                    node.Attributes.Append(attr);

                    parent.AppendChild(node);
                }
                break;

            case TypeCode.Int64:
                {
                    node = parent.OwnerDocument.CreateNode(XmlNodeType.Element, "Int64", "");

                    string strValue = Convert.ToString(objType);
                    if (node.Value == null)
                    {
                        node.InnerText = strValue;
                    }
                    else
                    {
                        node.Value = strValue;
                    }

                    XmlAttribute attr = node.OwnerDocument.CreateAttribute("name");
                    attr.Value = name;
                    node.Attributes.Append(attr);

                    parent.AppendChild(node);
                }
                break;

            case TypeCode.UInt64:
                {
                    node = parent.OwnerDocument.CreateNode(XmlNodeType.Element, "UInt64", "");

                    string strValue = Convert.ToString(objType);
                    if (node.Value == null)
                    {
                        node.InnerText = strValue;
                    }
                    else
                    {
                        node.Value = strValue;
                    }

                    XmlAttribute attr = node.OwnerDocument.CreateAttribute("name");
                    attr.Value = name;
                    node.Attributes.Append(attr);

                    parent.AppendChild(node);
                }
                break;

            case TypeCode.Single:
                {
                    node = parent.OwnerDocument.CreateNode(XmlNodeType.Element, "Single", "");

                    string strValue = Convert.ToString(objType);
                    if (node.Value == null)
                    {
                        node.InnerText = strValue;
                    }
                    else
                    {
                        node.Value = strValue;
                    }

                    XmlAttribute attr = node.OwnerDocument.CreateAttribute("name");
                    attr.Value = name;
                    node.Attributes.Append(attr);

                    parent.AppendChild(node);
                }
                break;

            case TypeCode.String:
                {
                    node = parent.OwnerDocument.CreateNode(XmlNodeType.Element, "String", "");

                    string strValue = Convert.ToString(objType);
                    if (node.Value == null)
                    {
                        node.InnerText = strValue;
                    }
                    else
                    {
                        node.Value = strValue;
                    }

                    XmlAttribute attr = node.OwnerDocument.CreateAttribute("name");
                    attr.Value = name;
                    node.Attributes.Append(attr);

                    parent.AppendChild(node);
                }
                break;

            case TypeCode.Object:
                {
                    /* Date:    6/26/2012
                     * Author:  XingPeng
                     * Desc:    特殊类型判定： XmlNode, List, Array 等判定
                     */
                    if (objType.GetType().IsArray && objType.GetType().HasElementType)
                    {
                        node = parent.OwnerDocument.CreateNode(XmlNodeType.Element, "Vector", "");

                        /*
                        string strValue = Convert.ToString(objType);
                        if (node.Value == null)
                        {
                            node.InnerText = strValue;
                        }
                        else
                        {
                            node.Value = strValue;
                        }*/

                        XmlAttribute attr = node.OwnerDocument.CreateAttribute("name");
                        attr.Value = name;
                        node.Attributes.Append(attr);

                        parent.AppendChild(node);




                        Array array = (Array)objType;
                        for (int i = 0; i < array.Length; i++)
                        {
                            object objItem = array.GetValue(i);
                            ConvetParamsToXmlForCPlus(ref objItem, ref node, "");
                        }
                    }
                    else if (objType.GetType().IsClass || objType.GetType().IsValueType)
                    {
                        node = parent.OwnerDocument.CreateNode(XmlNodeType.Element, "Object", "");

                        /*
                        string strValue = Convert.ToString(objType);
                        if (node.Value == null)
                        {
                            node.InnerText = strValue;
                        }
                        else
                        {
                            node.Value = strValue;
                        }*/

                        XmlAttribute attr = node.OwnerDocument.CreateAttribute("name");
                        attr.Value = name;
                        node.Attributes.Append(attr);
                        parent.AppendChild(node);

                        attr = node.OwnerDocument.CreateAttribute("id");
                        attr.Value = objType.GetType().FullName;
                        node.Attributes.Append(attr);
                        parent.AppendChild(node);

                        /* Date:    7/10/2012
                         * Author:  XingPeng
                         * Desc:    特殊类型判定： XmlNode判定
                         */
                        if (objType.GetType() == typeof(XmlNode))
                        {
                            break;
                        }


                        FieldInfo[] infos = objType.GetType().GetFields(BindingFlags.Instance | BindingFlags.Public);
                        //if (infos.Length == 0)
                        //{
                        //    infos = Serialize.AdaptToPlayMaker(objType.GetType(), infos);
                        //}
                        for (int i = 0; i < infos.Length; i++)
                        {
                            object objItem = null;
                            objItem = infos[i].GetValue(objType);
                            ConvetParamsToXmlForCPlus(ref objItem, ref node, infos[i].Name);
                        }

                    }
                    else
                    {
                        switch (objType.GetType().FullName)
                        {
                            case "":
                                {
                                }
                                break;

                            default:
                                {
                                    string errorString = objType.GetType().FullName;
                                    ActionManager.Add(() => { Debug.LogError("Unknown type infos in funciton name:" + errorString); return true; });
                                }
                                break;
                        }
                    }
                }
                break;

            default:
                {
                    string errorString = objType.GetType().FullName;
                    ActionManager.Add(() => { Debug.LogError("Unknown type infos in funciton name:" + errorString); return true; });
                }
                break;
        }
        return true;
    }
}
