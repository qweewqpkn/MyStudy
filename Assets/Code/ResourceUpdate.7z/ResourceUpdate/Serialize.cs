﻿/*
 * Name: 序列化类
 * File: Serialize.cs
 * Desc: 用于序列化通用协议
 * Date: 3/30/2012
 * Author：XingPeng
*/
using System;
using System.IO;
using System.Text;
using System.Xml;
using UnityEngine;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Runtime.Serialization.Formatters.Binary;

/*
 * Interface Name: ISerializeXml
 * Desc: 用于序列化通用对象
 * Date: 3/30/2012
 * Author：XingPeng
 * 
 * Date: 7/3/2012
 * Author: XingPeng
 * Desc: 创建者模式，重构序列化类
 * 
 * Date: 7/5/2012
 * Author: XingPeng
 * Desc: 提取接口
 * 
*/
public interface ISerializeXml
{
    /*
     * Name: Read
     * Desc: 反序列化
     *       FunctionName[String]ParamName[String]ParamType[Byte]ParamValue[Type]
     *       函数名 
     *       参数个数
     *       参数1（名称+类型+长度（可选）+成员/元素个数（可选）+值） 
     *       参数2（名称+类型+长度（可选）+成员/元素个数（可选）+值）
     *       
     *      <NetCall function="函数名称">
     *          <String name="参数1名称">    
     *              <参数1 /> 
     *          </String> 
     *          <Int name="参数2名称">    
     *              <参数2 /> 
     *          </Int> 
     *          <Vector name="参数3名称">    
     *              <String name="成员1名称">    
     *                  <成员1 /> 
     *              </String> 
     *          </Vector> 
     *       </NetCall>
     *       
     * Date: 3/30/2012
     * Author：XingPeng
     * 
     * Function:Read
     * Param:   data                        [IN]            数据
     *          doc                         [OUT]           解析后的数据
     * Return:  无
    */
    string Read(byte[] data, out XmlDocument doc);


    ///*
    // * Name: Read
    // * Desc: 反序列化
    // *       FunctionName[String]ParamName[String]ParamType[Byte]ParamValue[Type]
    // *       函数名 
    // *       参数个数
    // *       参数1（名称+类型+长度（可选）+成员/元素个数（可选）+值） 
    // *       参数2（名称+类型+长度（可选）+成员/元素个数（可选）+值）
    // *       在OBJECT和VECTOR中可以嵌套。
    // *       数据类型用1字节；成员/元素个数用4字节；其余按其对应的类型大小。
    // *       所有出现字符串的地方，都需要按照 长度+字串内容 的方式，无内容也需要长度填0；
    // *
    // *
    // *       
    // * Date: 3/30/2012
    // * Author：XingPeng
    // * 
    // * Function:Read
    // * Param:   br                          [IN]            数据流
    // *          parent                      [REF]           解析后的数据
    // * Return:  无
    //*/
    //void Read(ref BinaryReader br, ref XmlNode parent);


    /*
     * Name: Write
     * Desc: 序列化
     *       FunctionName[String]ParamName[String]ParamType[Byte]ParamValue[Type]
     *       函数名 
     *       参数个数
     *       参数1（名称+类型+长度（可选）+成员/元素个数（可选）+值） 
     *       参数2（名称+类型+长度（可选）+成员/元素个数（可选）+值）
     *       
     *      <NetCall function="函数名称">
     *          <String name="参数1名称">    
     *              <参数1 /> 
     *          </String> 
     *          <Int name="参数2名称">    
     *              <参数2 /> 
     *          </Int> 
     *          <Vector name="参数3名称">    
     *              <String name="成员1名称">    
     *                  <成员1 /> 
     *              </String> 
     *          </Vector> 
     *       </NetCall>
     * 
     * Date: 3/30/2012
     * Author：XingPeng
     * 
     * Function:Write
     * Param:   data                        [OUT]           序列化后数据
     *          parent                      [REF]           需要序列化的对象
     * Return:  无
    */
    void Write(out byte[] data, XmlDocument doc);


    ///*
    // * Name: Write
    // * Desc: 序列化
    // *       FunctionName[String]ParamName[String]ParamType[Byte]ParamValue[Type]
    // *       函数名 
    // *       参数个数
    // *       参数1（名称+类型+长度（可选）+成员/元素个数（可选）+值） 
    // *       参数2（名称+类型+长度（可选）+成员/元素个数（可选）+值）
    // *       
    // *       <NetCall function="函数名称">
    // *          <String name="参数1名称">    
    // *              <参数1 /> 
    // *          </String> 
    // *          <Int name="参数2名称">    
    // *              <参数2 /> 
    // *          </Int> 
    // *          <Vector name="参数3名称">    
    // *              <String name="成员1名称">    
    // *                  <成员1 /> 
    // *              </String> 
    // *          </Vector> 
    // *       </NetCall>
    // *       
    // * Date: 3/30/2012
    // * Author：XingPeng
    // * 
    // * Function:Write
    // * Param:
    // * Return:
    //*/
    //void Write(ref BinaryWriter bw, XmlNode parent);

}


/*
 * Interface Name: ISerializeObject
 * Desc: 用于序列化通用对象
 * Date: 3/30/2012
 * Author：XingPeng
 * 
 * Date: 7/3/2012
 * Author: XingPeng
 * Desc: 创建者模式，重构序列化类
 * 
 * Date: 7/5/2012
 * Author: XingPeng
 * Desc: 提取接口
 * 
*/
public interface ISerializeObject
{
    /*
     * Name: Read
     * Desc: 反序列化
     *       FunctionName[String]ParamName[String]ParamType[Byte]ParamValue[Type]
     *       函数名 
     *       参数个数
     *       参数1（名称+类型+长度（可选）+成员/元素个数（可选）+值） 
     *       参数2（名称+类型+长度（可选）+成员/元素个数（可选）+值）
     *       
     *      <NetCall function="函数名称">
     *          <String name="参数1名称">    
     *              <参数1 /> 
     *          </String> 
     *          <Int name="参数2名称">    
     *              <参数2 /> 
     *          </Int> 
     *          <Vector name="参数3名称">    
     *              <String name="成员1名称">    
     *                  <成员1 /> 
     *              </String> 
     *          </Vector> 
     *       </NetCall>
     *       
     * Date: 3/30/2012
     * Author：XingPeng
     * 
     * Function:Read
     * Param:   data                        [IN]            数据
     *          doc                         [OUT]           解析后的数据
     * Return:  无
    */
    string Read(byte[] data, out object doc);


    ///*
    // * Name: Read
    // * Desc: 反序列化
    // *       FunctionName[String]ParamName[String]ParamType[Byte]ParamValue[Type]
    // *       函数名 
    // *       参数个数
    // *       参数1（名称+类型+长度（可选）+成员/元素个数（可选）+值） 
    // *       参数2（名称+类型+长度（可选）+成员/元素个数（可选）+值）
    // *       在OBJECT和VECTOR中可以嵌套。
    // *       数据类型用1字节；成员/元素个数用4字节；其余按其对应的类型大小。
    // *       所有出现字符串的地方，都需要按照 长度+字串内容 的方式，无内容也需要长度填0；
    // *
    // *
    // *       
    // * Date: 3/30/2012
    // * Author：XingPeng
    // * 
    // * Function:Read
    // * Param:   br                          [IN]            数据流
    // *          parent                      [REF]           解析后的数据
    // * Return:  无
    //*/
    //void Read(ref BinaryReader br, ref object parent);


    /*
     * Name: Write
     * Desc: 序列化
     *       FunctionName[String]ParamName[String]ParamType[Byte]ParamValue[Type]
     *       函数名 
     *       参数个数
     *       参数1（名称+类型+长度（可选）+成员/元素个数（可选）+值） 
     *       参数2（名称+类型+长度（可选）+成员/元素个数（可选）+值）
     *       
     *      <NetCall function="函数名称">
     *          <String name="参数1名称">    
     *              <参数1 /> 
     *          </String> 
     *          <Int name="参数2名称">    
     *              <参数2 /> 
     *          </Int> 
     *          <Vector name="参数3名称">    
     *              <String name="成员1名称">    
     *                  <成员1 /> 
     *              </String> 
     *          </Vector> 
     *       </NetCall>
     * 
     * Date: 3/30/2012
     * Author：XingPeng
     * 
     * Function:Write
     * Param:   data                        [OUT]           序列化后数据
     *          parent                      [REF]           需要序列化的对象
     * Return:  无
    */
    void Write(out byte[] data, ref object doc);


    ///*
    // * Name: Write
    // * Desc: 序列化
    // *       FunctionName[String]ParamName[String]ParamType[Byte]ParamValue[Type]
    // *       函数名 
    // *       参数个数
    // *       参数1（名称+类型+长度（可选）+成员/元素个数（可选）+值） 
    // *       参数2（名称+类型+长度（可选）+成员/元素个数（可选）+值）
    // *       
    // *       <NetCall function="函数名称">
    // *          <String name="参数1名称">    
    // *              <参数1 /> 
    // *          </String> 
    // *          <Int name="参数2名称">    
    // *              <参数2 /> 
    // *          </Int> 
    // *          <Vector name="参数3名称">    
    // *              <String name="成员1名称">    
    // *                  <成员1 /> 
    // *              </String> 
    // *          </Vector> 
    // *       </NetCall>
    // *       
    // * Date: 3/30/2012
    // * Author：XingPeng
    // * 
    // * Function:Write
    // * Param:
    // * Return:
    //*/
    //void Write(ref BinaryWriter bw, object parent);

}


/*
 * Class Name: Serialize
 * Desc: 用于序列化通用对象
 * Date: 3/30/2012
 * Author：XingPeng
 * 
 * Date: 7/3/2012
 * Author: XingPeng
 * Desc: 创建者模式，重构序列化类
 * 
*/
public abstract class Serialize
{
	// yadou 反射生成对象 耗性能
    public static Dictionary<Type, ICloneable> g_DicInstanceCach = new Dictionary<Type, ICloneable>();

    public static void AddTypeDic(Type t,object ot)
    {
        if(!(ot is ICloneable))
        {
            return;
        }

        ICloneable o ;
        if(g_DicInstanceCach.TryGetValue(t,out o))
        {

        }
        else
        {
            g_DicInstanceCach.Add(t, (ICloneable)ot);
        }
    }
    public static object GetTypeInstanceCach(Type t)
    {
        ICloneable o = null;
        if( g_DicInstanceCach.TryGetValue(t, out o))
        {
            //浅拷贝 对象内部对象结构是引用 因反射生成的时候都是null 所以这边不用管

            return o.Clone();

        }
        else
        {
            return null;
        }


    }
    static Dictionary<Type, Dictionary<string, MethodInfo>> funcs = new Dictionary<Type, Dictionary<string, MethodInfo>>();

    /*
     * Name: ReadString
     * Desc: 缓存反射方法
     * Date: 5/6/2015
     * Author：XingPeng
     * 
     * Function:GetFunc
     * Param:   t                           [IN]        缓存的类型
     *          funcName                    [IN]        缓存的函数名称
     * Return:  MethodInfo:缓存的反射方法
    */
    public static MethodInfo GetFunc(Type t, string funcName)
    {
        Dictionary<string, MethodInfo> info;
        MethodInfo mi = null;
        if (false == funcs.TryGetValue(t, out info))
        {
            mi = t.GetMethod(funcName);
            info = new Dictionary<string, MethodInfo>();
            info.Add(funcName, mi);
            funcs.Add(t, info);

            return mi;
        }


        if (false == info.TryGetValue(funcName, out mi))
        {
            mi = t.GetMethod(funcName);
            info.Add(funcName, mi);
        }
        return mi;
    }


    /*
     * Name: ReadString
     * Desc: 反序列化字符串，使用ANSI编码
     * Date: 4/5/2012
     * Author：XingPeng
     * 
     * Function:ReadString
     * Param:   br                          [REF]            数据流，源
     * Return:  string:读取的字符串
    */
    public virtual string ReadString(ref BinaryReader br)
    {
        int iLeng = br.ReadInt32();

        byte[] btValue = br.ReadBytes(iLeng);
        return Encoding.Default.GetString(btValue);
    }

    /*
     * Name: WriteString
     * Desc: 序列化字符串，使用ANSI编码
     * Date: 4/5/2012
     * Author：XingPeng
     * 
     * Function:WriteString
     * Param:   br                          [REF]           数据流，目标
     *          strValue                    [IN]            序列化的字符串
     * Return:  无
    */
    public virtual void WriteString(ref BinaryWriter bw, string strValue)
    {
        byte[] btName = Encoding.Default.GetBytes(strValue);
        bw.Write(btName.Length);
        bw.Write(btName);

        return;
    }

    /*
     * Name: ConvetParamsToXml
     * Desc: 转换参数类型，类型检测
     *       使用反射，设置参数序列
     * Date: 7/11/2012
     * Author：XingPeng
     * 
     * Function: ConvetParamsToXmlForCPlus   
     * Param:   objType             [REF]        源对象
     *          parent              [REF]        父对象
     *          name                [REF]        字段名称
     * Return:  无
    */
    public static bool ConvetParamsToXmlForCPlus(ref System.Object objType, ref XmlNode parent, string name)
    {
        XmlNode node;
        if (parent == null || objType == null)
        {
            // Debug.LogError("Unknown params infos in :" + type.Name);

            return false;
        }


        switch (Type.GetTypeCode(objType.GetType()))
        {
            case TypeCode.Boolean:
                {
                    node = parent.OwnerDocument.CreateNode(XmlNodeType.Element, "BOOL", "");

                    string strValue = Convert.ToString(objType);
                    if (node.Value == null)
                    {
                        node.InnerText = strValue;
                    }
                    else
                    {
                        node.Value = strValue;
                    }

                    XmlAttribute attr = node.OwnerDocument.CreateAttribute("name");
                    attr.Value = objType.GetType().Name;
                    node.Attributes.Append(attr);

                    parent.AppendChild(node);
                } break;

            case TypeCode.Char:
                {
                    node = parent.OwnerDocument.CreateNode(XmlNodeType.Element, "Char", "");

                    string strValue = Convert.ToString(objType);
                    if (node.Value == null)
                    {
                        node.InnerText = strValue;
                    }
                    else
                    {
                        node.Value = strValue;
                    }

                    XmlAttribute attr = node.OwnerDocument.CreateAttribute("name");
                    attr.Value = name;
                    node.Attributes.Append(attr);

                    parent.AppendChild(node);
                } break;

            case TypeCode.Byte:
                {
                    node = parent.OwnerDocument.CreateNode(XmlNodeType.Element, "Byte", "");

                    string strValue = Convert.ToString(objType);
                    if (node.Value == null)
                    {
                        node.InnerText = strValue;
                    }
                    else
                    {
                        node.Value = strValue;
                    }

                    XmlAttribute attr = node.OwnerDocument.CreateAttribute("name");
                    attr.Value = name;
                    node.Attributes.Append(attr);

                    parent.AppendChild(node);
                } break;

            case TypeCode.Int16:
                {
                    node = parent.OwnerDocument.CreateNode(XmlNodeType.Element, "Int16", "");

                    string strValue = Convert.ToString(objType);
                    if (node.Value == null)
                    {
                        node.InnerText = strValue;
                    }
                    else
                    {
                        node.Value = strValue;
                    }

                    XmlAttribute attr = node.OwnerDocument.CreateAttribute("name");
                    attr.Value = name;
                    node.Attributes.Append(attr);

                    parent.AppendChild(node);
                } break;

            case TypeCode.UInt16:
                {
                    node = parent.OwnerDocument.CreateNode(XmlNodeType.Element, "UInt16", "");

                    string strValue = Convert.ToString(objType);
                    if (node.Value == null)
                    {
                        node.InnerText = strValue;
                    }
                    else
                    {
                        node.Value = strValue;
                    }

                    XmlAttribute attr = node.OwnerDocument.CreateAttribute("name");
                    attr.Value = name;
                    node.Attributes.Append(attr);

                    parent.AppendChild(node);
                } break;

            case TypeCode.Int32:
                {
                    node = parent.OwnerDocument.CreateNode(XmlNodeType.Element, "Int32", "");

                    string strValue = Convert.ToString(objType);
                    if (node.Value == null)
                    {
                        node.InnerText = strValue;
                    }
                    else
                    {
                        node.Value = strValue;
                    }

                    XmlAttribute attr = node.OwnerDocument.CreateAttribute("name");
                    attr.Value = name;
                    node.Attributes.Append(attr);

                    parent.AppendChild(node);
                } break;

            case TypeCode.UInt32:
                {
                    node = parent.OwnerDocument.CreateNode(XmlNodeType.Element, "UInt32", "");

                    string strValue = Convert.ToString(objType);
                    if (node.Value == null)
                    {
                        node.InnerText = strValue;
                    }
                    else
                    {
                        node.Value = strValue;
                    }

                    XmlAttribute attr = node.OwnerDocument.CreateAttribute("name");
                    attr.Value = name;
                    node.Attributes.Append(attr);

                    parent.AppendChild(node);
                } break;

            case TypeCode.Int64:
                {
                    node = parent.OwnerDocument.CreateNode(XmlNodeType.Element, "Int64", "");

                    string strValue = Convert.ToString(objType);
                    if (node.Value == null)
                    {
                        node.InnerText = strValue;
                    }
                    else
                    {
                        node.Value = strValue;
                    }

                    XmlAttribute attr = node.OwnerDocument.CreateAttribute("name");
                    attr.Value = name;
                    node.Attributes.Append(attr);

                    parent.AppendChild(node);
                } break;

            case TypeCode.UInt64:
                {
                    node = parent.OwnerDocument.CreateNode(XmlNodeType.Element, "UInt64", "");

                    string strValue = Convert.ToString(objType);
                    if (node.Value == null)
                    {
                        node.InnerText = strValue;
                    }
                    else
                    {
                        node.Value = strValue;
                    }

                    XmlAttribute attr = node.OwnerDocument.CreateAttribute("name");
                    attr.Value = name;
                    node.Attributes.Append(attr);

                    parent.AppendChild(node);
                } break;

            case TypeCode.Single:
                {
                    node = parent.OwnerDocument.CreateNode(XmlNodeType.Element, "Single", "");

                    string strValue = Convert.ToString(objType);
                    if (node.Value == null)
                    {
                        node.InnerText = strValue;
                    }
                    else
                    {
                        node.Value = strValue;
                    }

                    XmlAttribute attr = node.OwnerDocument.CreateAttribute("name");
                    attr.Value = name;
                    node.Attributes.Append(attr);

                    parent.AppendChild(node);
                } break;

            case TypeCode.String:
                {
                    node = parent.OwnerDocument.CreateNode(XmlNodeType.Element, "String", "");

                    string strValue = Convert.ToString(objType);
                    if (node.Value == null)
                    {
                        node.InnerText = strValue;
                    }
                    else
                    {
                        node.Value = strValue;
                    }

                    XmlAttribute attr = node.OwnerDocument.CreateAttribute("name");
                    attr.Value = name;
                    node.Attributes.Append(attr);

                    parent.AppendChild(node);
                } break;

            case TypeCode.Object:
                {
                    /* Date:    6/26/2012
                     * Author:  XingPeng
                     * Desc:    特殊类型判定： XmlNode, List, Array 等判定
                     */
                    if (objType.GetType().IsArray && objType.GetType().HasElementType)
                    {
                        node = parent.OwnerDocument.CreateNode(XmlNodeType.Element, "Vector", "");
				
						/*
                        string strValue = Convert.ToString(objType);
                        if (node.Value == null)
                        {
                            node.InnerText = strValue;
                        }
                        else
                        {
                            node.Value = strValue;
                        }*/

                        XmlAttribute attr = node.OwnerDocument.CreateAttribute("name");
                        attr.Value = name;
                        node.Attributes.Append(attr);

                        parent.AppendChild(node);

                        


                        Array array = (Array)objType;
                        for (int i=0; i < array.Length; i++)
                        {
                            object objItem = array.GetValue(i);
                            ConvetParamsToXmlForCPlus(ref objItem, ref node, "");
                        }
                    }
                    else if (objType.GetType().IsClass || objType.GetType().IsValueType)
                    {
                        node = parent.OwnerDocument.CreateNode(XmlNodeType.Element, "Object", "");
				
						/*
                        string strValue = Convert.ToString(objType);
                        if (node.Value == null)
                        {
                            node.InnerText = strValue;
                        }
                        else
                        {
                            node.Value = strValue;
                        }*/

                        XmlAttribute attr = node.OwnerDocument.CreateAttribute("name");
                        //attr.Value = name;
                        attr.Value = objType.GetType().Name;
                        node.Attributes.Append(attr);
                        parent.AppendChild(node);
				
				
                        //attr = node.OwnerDocument.CreateAttribute("id");
                        //attr.Value = objType.GetType().Name;
                        //node.Attributes.Append(attr);
                        //parent.AppendChild(node);
						




                        /* Date:    7/10/2012
                         * Author:  XingPeng
                         * Desc:    特殊类型判定： XmlNode判定
                         */
                        if (objType.GetType() == typeof(XmlNode))
                        {
                            break;
                        }


                        FieldInfo[] infos = objType.GetType().GetFields();
                        for (int i=0; i < infos.Length; i++)
                        {
                            object objItem = null;
                            objItem = infos[i].GetValue(objType);
                            ConvetParamsToXmlForCPlus(ref objItem, ref node, infos[i].Name);
                        }

                    }
                    else
                    {
                        switch (objType.GetType().FullName)
                        {
                            case "":
                                {
                                } break;

                            default:
                                {
                                    string errorString = objType.GetType().FullName;
                                    ActionManager.Add(() => { 
                                        

                                        Debug.LogError("Unknown type infos in funciton name:" + errorString); return true; 

                                    
                                    });
                                } break;
                        }
                    }
                } break;

            default:
                {
                    string errorString = objType.GetType().FullName;
                    ActionManager.Add(() => { Debug.LogError("Unknown type infos in funciton name:" + errorString); return true; });
                } break;
        }


        return true;

    }


    /*
     * Name: ConvertValue
     * Desc: 转换参数类型，类型检测
     *       使用反射，设置参数序列
     * Date: 6/26/2012
     * Author：XingPeng
     * 
     * Date:    08/27/2012
     * Modify:  XingPeng
     * Desc:    提取基本类型转换
     * 
     * Function: ConvertValue   
     * Param:   code                [IN]        类型
     *          value               [IN]        值
     *          obj                 [REF]       对应的参数
     *                                          传入XmlNode  传出的是打包的对应数据
     *          
     * Return:  无
    */
    public static void ConvertValue(TypeCode code, String value, ref object obj)
    {
        switch (code)
        {
            case TypeCode.Boolean:
                {
                    int objvalint = 0;

                    if (int.TryParse(value, out objvalint))
                    {
                        if(objvalint!=0)
                        {
                            obj = true;
                        }
                        else
                        {
                            obj = false;
                        }
                    }
                    else
                    {

                        Boolean oValue = false;
                        Boolean.TryParse(value, out oValue);
                        obj = oValue;
                    }
                    
                } break;

            case TypeCode.Char:
                {
                    Char oValue = '\0';
                    Char.TryParse(value, out oValue);

                    obj = oValue;
                } break;

            case TypeCode.Byte:
                {
                    Byte oValue = 0;
                    Byte.TryParse(value, out oValue);

                    obj = oValue;
                } break;

            case TypeCode.Int16:
                {
                    Int16 oValue = 0;
                    Int16.TryParse(value, out oValue);

                    obj = oValue;
                } break;

            case TypeCode.UInt16:
                {
                    UInt16 oValue = 0;
                    UInt16.TryParse(value, out oValue);

                    obj = oValue;
                } break;

            case TypeCode.Int32:
                {
                    Int32 oValue = 0;
                    Int32.TryParse(value, out oValue);

                    obj = oValue;
                } break;

            case TypeCode.UInt32:
                {
                    UInt32 oValue = 0;
                    UInt32.TryParse(value, out oValue);

                    obj = oValue;
                } break;

            case TypeCode.Int64:
                {
                    Int64 oValue = 0;
                    Int64.TryParse(value, out oValue);

                    obj = oValue;
                } break;

            case TypeCode.UInt64:
                {
                    UInt64 oValue = 0;
                    UInt64.TryParse(value, out oValue);

                    obj = oValue;
                } break;

            case TypeCode.Single:
                {
                    Single oValue = 0;
                    Single.TryParse(value, out oValue);

                    obj = oValue;
                } break;

            case TypeCode.String:
                {
                    obj = value;
                } break;
        }
    }


    /*
     * Name: ConvetParamsToType
     * Desc: 转换参数类型，类型检测
     *       使用反射，设置参数序列
     * Date: 6/26/2012
     * Author：XingPeng
     * 
     * Function: ConvetParamsToType   
     * Param:   type                [IN]        类型
     *          obj                 [REF]       对应的参数
     *                                          传入XmlNode  传出的是打包的对应数据
     *          
     * Return:  无
    */
    public static bool ConvetParamsToType(Type type, ref System.Object obj)
    {
        XmlNode node = obj as XmlNode;
        if (node == null)
        {
            // Debug.LogError("Unknown params infos in :" + type.Name);

            return false;
        }


        switch (Type.GetTypeCode(type))
        {
            case TypeCode.Boolean:
            case TypeCode.Char:
            case TypeCode.Byte:
            case TypeCode.Int16:
            case TypeCode.UInt16:
            case TypeCode.Int32:
            case TypeCode.UInt32:
            case TypeCode.Int64:
            case TypeCode.UInt64:
            case TypeCode.Single:
            case TypeCode.String:
                {
                    ConvertValue(Type.GetTypeCode(type), node.InnerText, ref obj);
                } break;

            case TypeCode.Object:
                {
                    /* Date:    6/26/2012
                     * Author:  XingPeng
                     * Desc:    特殊类型判定： XmlNode, List, Array 等判定
                     */
                    if (type.IsArray && type.HasElementType)
                    {
                        if (node.Name.Equals("Vector", StringComparison.OrdinalIgnoreCase) ||
                            node.Name.Equals("ARRAY", StringComparison.OrdinalIgnoreCase) )
                        {
                            XmlNodeList nodeList = node.SelectNodes("./*");
                            if (nodeList.Count == 0)
                            {
								obj = null;
                                break;
                            }

                            /*
                             * 修改实例化的方式，因为il2cpp后不支持直接实例化一个数组
                             * 2015-3-6 liuxu
                             */ 
                            //obj = Activator.CreateInstance(type, new object[] { nodeList.Count });
                            Array objList = Array.CreateInstance(type.GetElementType(),nodeList.Count);
                            obj = objList;

                            Array array = (Array)obj;
                            for (int i=0; i < nodeList.Count; i++)
                            {
                                XmlNode nodeItem = nodeList[i];

                                object result = nodeItem;
                                ConvetParamsToType(type.GetElementType(), ref result);

                                array.SetValue(result, i);
                            }
                        }
                    }
                    else if (type.IsClass || type.IsValueType)  //加入IsValueType保证Struct类型的适配 added by XiangJiYu 2014/7/28
                    {
                        if (node.Name.Equals("Object", StringComparison.OrdinalIgnoreCase) ||
                            node.Name.Equals("INT_TUPLE", StringComparison.OrdinalIgnoreCase) ||
                            node.Name.Equals("NetCall", StringComparison.OrdinalIgnoreCase))
                        {
                            XmlNodeList nodeList = node.SelectNodes("./*");
                            List<XmlNode> list = new List<XmlNode>();
                            for (int i = 0; i < node.Attributes.Count;i++ )
                            {
                                XmlNode nodeItem = node.Attributes[i]; 
                                list.Add(nodeItem);
                            }
                            // 提高性能
                            foreach(XmlNode nodeItem in nodeList)
                            {
                                list.Add(nodeItem);
                            }

                            /* Date:    6/26/2012
                             * Author:  XingPeng
                             * Desc:    特殊类型判定： XmlNode判定
                             */
                            if (type == typeof(XmlNode))
                            {
                                break;
                            }

                            obj = Activator.CreateInstance(type);

                            FieldInfo[] infos = type.GetFields();
                            for (int i=0; i < list.Count; i++)
                            {
                                string strFieldName = "";
                                XmlNode nodeItem = list[i];
                                XmlAttribute attr = nodeItem as XmlAttribute;
                                if (attr == null)
                                {
                                    attr = nodeItem.Attributes["name"];
                                    if (attr == null)
                                        attr = nodeItem.Attributes["Name"];
                                    if (attr == null)
                                        attr = nodeItem.Attributes["function"];
                                    if (attr == null)
                                        attr = nodeItem.Attributes["Function"];

                                    if (attr != null)
                                        strFieldName = attr.Value;
                                }
                                else
                                {
                                    strFieldName = attr.Name;
                                }
                                /*if (attr == null)
                                    continue;*/

                                if (strFieldName == "")
                                {
                                    if (infos.Length < i)
                                    {
										continue;
									}
							
                                    FieldInfo info = infos[i];
                                    object result = nodeItem;
                                    ConvetParamsToType(info.FieldType, ref result);

                                    info.SetValue(obj, result);
                                }
                                else
                                {
                                    for (int j = 0; j < infos.Length; j++)
                                    {
                                        FieldInfo info = infos[j];
                                        if (info.Name == strFieldName)
                                        {
                                            object result = nodeItem;
                                            try
                                            {
                                                ConvetParamsToType(info.FieldType, ref result);
                                            }
                                            catch(Exception)
                                            {
                                                string errorString = obj.ToString();
                                                ActionManager.Add(() => { Debug.LogError("Error serialize " + errorString); return true; });
                                            }
									
                                            if (info.FieldType == typeof(XmlNode))
                                            {
                                                 info.SetValue(obj, result);
                                                 break;
                                            }
                                            if (!info.FieldType.IsArray && nodeItem.Name.Equals("ARRAY", StringComparison.OrdinalIgnoreCase))
                                            {
                                                /*
                                                 * Date:	2012/8/22
                                                 * Author:	XingPeng
                                                 * Desc:	添加空值,INT_TUPLE中传入Nil值
                                                 */
                                                break;
                                            }
									
                                            info.SetValue(obj, result);
									
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        switch (type.FullName)
                        {
                            case "":
                                {
                                } break;

                            default:
                                {
                                    string errorString = type.FullName;
                                    ActionManager.Add(() => { Debug.LogError("Unknown type infos in funciton name:" + errorString); return true; });
                                } break;
                        }
                    }
                } break;

            default:
                {
                    string errorString = type.FullName;
                    ActionManager.Add(() => { Debug.LogError("Unknown type infos in funciton name:" + errorString); return true; });
                } break;
        }

        return true;
    }


    /*
     * Name: ConvetParamsToType
     * Desc: 转换参数类型，类型检测
     *       使用反射，设置参数序列
     * Date: 6/26/2012
     * Author：XingPeng
     * 
     * Function: ConvetParamsToType   
     * Param:   methord             [IN]        方法
     *          bNamePair           [IN]        匹配名称
     *          args                [REF]       对应的参数
     *          
     * Return:  无
    */
    //public static void ConvetParamsToType(MethodInfo methord, bool bNamePair, ref System.Object[] args)
    //{
    //    ConvetParamsToType(methord, bNamePair, true, ref args);
    //}

    /*
     * Name: ConvetParamsToType
     * Desc: 转换参数类型，类型检测
     *       使用反射，设置参数序列
     * Date: 6/26/2012
     * Author：XingPeng
     * 
     * Function: ConvetParamsToType   ConvertValue(Type.GetTypeCode(type), node.InnerText, ref obj);
     * Param:   methord             [IN]        方法
     *          args                [REF]       对应的参数
     *          
     * Return:  无
    */
    private static void ConvetParamsToType(MethodInfo methord, ref System.Object[] args)
    {
        ParameterInfo[] parameters = methord.GetParameters();
        if (parameters.Length != args.Length)
        {
            string errorString = methord.Name;
            ActionManager.Add(() => { Debug.LogError("The funciton:" + errorString + "'call has correct paremeters."); return true; });
            return;
        }


        for (int j = 0; j < parameters.Length; j++)
        {
            ParameterInfo paramInfo = parameters[j];
            Type t = paramInfo.ParameterType;
            ConvertValue(Type.GetTypeCode(t), (String)args[paramInfo.Position], ref args[paramInfo.Position]);
        }
    }


    /*
     * Name: ConvetParamsToType
     * Desc: 转换参数类型，类型检测
     *       使用反射，设置参数序列
     * Date: 6/26/2012
     * Author：XingPeng
     * 
     * Function: ConvetParamsToType   ConvertValue(Type.GetTypeCode(type), node.InnerText, ref obj);
     * Param:   methord             [IN]        方法
     *          bNamePair           [IN]        匹配名称
     *          args                [REF]       对应的参数
     *          
     * Return:  无
    */
    public static void ConvetParamsToType(MethodInfo methord, bool bNamePair, ref System.Object[] args)
    {
        ParameterInfo[] parameters = methord.GetParameters();
        if (parameters.Length != args.Length && false == bNamePair)
        {
            string errorString = methord.Name;
            ActionManager.Add(() => { Debug.LogError("The funciton:" + errorString + "'call has correct paremeters."); return true; });
            return;
        }


        if (bNamePair)
        {
            List<System.Object> listArgs = new List<object>();

            for (int j = 0; j < parameters.Length; j++)
            {
                ParameterInfo paramInfo = parameters[j];

                bool bPair = false;
                Type t = paramInfo.ParameterType;

                for (int i = 0; i < args.Length; i++)
                {
                    System.Object obj = args[i];
                    XmlNode node = obj as XmlNode;
                    if (node == null)
                        continue;

                    XmlAttribute attr = node.Attributes["name"];
                    if (attr == null)
                        continue;

                    if (paramInfo.Name != attr.Value)
                        continue;

                    bPair = true;
                    Serialize.ConvetParamsToType(t, ref obj);
                    listArgs.Add(obj);
                }


                if (false == bPair)
                {
                    TypeCode code = Type.GetTypeCode(paramInfo.ParameterType);
                    switch (code)
                    {
                        case TypeCode.Object:
                            {
                                listArgs.Add(null);
                            } break;

                        default:
                            {
                                System.Object obj = null;
                                Serialize.ConvertValue(code, "", ref obj);
                                listArgs.Add(obj);
                            } break;
                    }
                }
            }

            args = listArgs.ToArray();
        }
        else
        {
            for (int j = 0; j < parameters.Length; j++)
            {
                ParameterInfo paramInfo = parameters[j];
                Type t = paramInfo.ParameterType;

                Serialize.ConvetParamsToType(t, ref args[paramInfo.Position]);
            }
        }

    }


    /*
     * Name: Object
     * Desc: 设置属性
     * Date: 8/27/2012
     * Author：XingPeng
     * 
     * 
     * Modify:  XingPeng
     * Date:    01/21/2014
     * Desc:    重构，增加属性项解析
     * 
     * 
     * Function: SetObjectValue   
     * Param:   obj                 [REF]       目标结点
     *          name                [IN]        属性          <@开头表示属性名，否者为字段名; .增加对象层级; :函数调用; ,参数分隔>
     *          value               [IN]        属性值       
     * Return:  无
    */
    [Obsolete]
    public static bool SetObjectValue(object obj, String name, String value)
    {
        if (obj == null)
            return false;

        string[] names = name.Split(new char[] { '.' });
        if (names.Length > 0)
        {
            string key = names[0];
            if (key.StartsWith("@"))
            {
                if (key.Contains(":"))
                {
                    string[] strParams = key.Split(new char[] { ':', ',' });
                    // 函数调用

                    System.Reflection.MethodInfo method = null;
                    /*XingPeng
                        Desc:扩展函数调用*/
                    method = GetFunc(obj.GetType(), strParams[0].Substring(1));
                    if (method != null)
                    {
                        if (names.Length > 1)
                        {
                            object objField = null;
                            if (strParams.Length > 1)
                            {
                                System.Object[] param = new System.Object[strParams.Length - 1];
                                Array.Copy(strParams, 1, param, 0, param.Length);

                                ConvetParamsToType(method, ref param);
                                objField = method.Invoke(obj, param);
                            }
                            else
                            {
                                objField = method.Invoke(obj, null);
                            }

                            return SetObjectValue(objField, name.Substring(key.Length + 1), value);
                        }
                        else
                        {
                            // 忽略value数值
                            //object result = value;
                            //ConvetParamsToType(obj.GetType(), ref result);
                            //System.Object[] args = value as System.Object[];
                            //method.Invoke(obj, args);

                            object objField = null;
                            if (strParams.Length > 1)
                            {
                                System.Object[] param = new System.Object[strParams.Length - 1];
                                Array.Copy(strParams, 1, param, 0, param.Length);

                                ConvetParamsToType(method, ref param);
                                objField = method.Invoke(obj, param);
                            }
                            else
                            {
                                objField = method.Invoke(obj, null);
                            }

                            return true;
                        }
                    }
                }
                else
                {
                    // 属性调用
                    System.Reflection.PropertyInfo property = null;

                    /*XingPeng
                        Desc:用于隐藏MVC中的Mod*/
                    if (key.Equals("@Mod"))
                    {
                        property = obj.GetType().GetProperty(key.Substring(1), BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                    }
                    else
                    {
                        property = obj.GetType().GetProperty(key.Substring(1));
                    }

                    if (property != null)
                    {
                        if (names.Length > 1)
                        {
                            object objField = property.GetValue(obj, null);
                            return SetObjectValue(objField, name.Substring(key.Length + 1), value);
                        }
                        else
                        {
                            object result = value;
                            ConvertValue(Type.GetTypeCode(property.PropertyType), value, ref result);
                            property.SetValue(obj, result, null);
                            return true;
                        }
                    }
                }
            }
            else if (key.Contains("[") && key.EndsWith("]"))
            {
                string[] strParams = key.Split(new char[] { '[', ']' });
                // 数组调用

                System.Reflection.FieldInfo field = null;
                /*XingPeng
                    Desc:扩展数组调用*/
                field = obj.GetType().GetField(strParams[0]);
                if (field != null)
                {
                    obj = field.GetValue(obj);

                    Array array = (Array)obj;
                    Int64 index = 0;
                    Int64.TryParse(strParams[1], out index);
                    if (array == null || array.Length <= index)
                        return false;

                    if (names.Length > 1)
                    {
                        obj = array.GetValue(index);
                        return SetObjectValue(obj, name.Substring(key.Length + 1), value);
                    }
                    else
                    {
                        // 忽略String表达式中的参数表
                        object result = value;
                        ConvertValue(Type.GetTypeCode(field.FieldType), value, ref result);
                        array.SetValue(result, index);

                        return true;
                    }
                }
            }
            else
            {

             
                FieldInfo[] infos = obj.GetType().GetFields();
                foreach (FieldInfo info in infos)
                {
                    if (info.Name == key || info.Name.EndsWith("." + key))
                    {
                        if (names.Length > 1)
                        {
                            object objField = info.GetValue(obj);
                            return SetObjectValue(objField, name.Substring(key.Length + 1), value);
                        }
                        else
                        {
                            object result = value;
                            ConvertValue(Type.GetTypeCode(info.FieldType), value, ref result);
                            info.SetValue(obj, result);
                            return true;
                        }
                    }
                }
            }
        }

        return false;
    }


    /*
     * Name: Object
     * Desc: 设置属性
     * Date: 8/27/2012
     * Author：XingPeng
     * 
     * 
     * Modify:  XingPeng
     * Date:    01/21/2014
     * Desc:    重构，增加属性项解析
     * 
     * 
     * Function: SetObjectValue   
     * Param:   obj                 [REF]       目标结点
     *          name                [IN]        属性          <@开头表示属性名，否者为字段名; .增加对象层级; :函数调用; ,参数分隔>
     *          value               [IN]        属性值       
     * Return:  无
    */
    public static bool SetObjectValue(object obj, String name, object value)
    {
        if (obj == null)
            return false;

        string[] names = name.Split(new char[] { '.' });
        if (names.Length > 0)
        {
            string key = names[0];
            if (key.StartsWith("@"))
            {
                if (key.Contains(":"))
                {
                    string[] strParams = key.Split(new char[] { ':', ',' });
                    // 函数调用

                    System.Reflection.MethodInfo method = null;
                    /*XingPeng
                        Desc:扩展函数调用*/
                    method = GetFunc(obj.GetType(), strParams[0].Substring(1));
                    if (method != null)
                    {
                        if (names.Length > 1)
                        {
                            object objField = null;
                            if (strParams.Length > 1)
                            {
                                System.Object[] param = new System.Object[strParams.Length - 1];
                                Array.Copy(strParams, 1, param, 0, param.Length);

                                ConvetParamsToType(method, ref param);
                                objField = method.Invoke(obj, param);
                            }
                            else
                            {
                                objField = method.Invoke(obj, null);
                            }

                            return SetObjectValue(objField, name.Substring(key.Length + 1), value);
                        }
                        else
                        {
                            // 忽略String表达式中的参数表
                            System.Object[] args = value as System.Object[];
                            method.Invoke(obj, args);

                            return true;
                        }
                    }
                }
                else
                {
                    // 属性调用
                    System.Reflection.PropertyInfo property = null;

                    /*XingPeng
                        Desc:用于隐藏MVC中的Mod*/
                    if (key.Equals("@Mod"))
                    {
                        property = obj.GetType().GetProperty(key.Substring(1), BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                    }
                    else
                    {
                        property = obj.GetType().GetProperty(key.Substring(1));
                    }

                    if (property != null)
                    {
                        if (names.Length > 1)
                        {
                            object objField = property.GetValue(obj, null);
                            return SetObjectValue(objField, name.Substring(key.Length + 1), value);
                        }
                        else
                        {
                            property.SetValue(obj, value, null);
                            return true;
                        }
                    }
                }
            }
            else if (key.Contains("[") && key.EndsWith("]"))
            {
                string[] strParams = key.Split(new char[] { '[', ']' });
                // 数组调用

                System.Reflection.FieldInfo field = null;
                /*XingPeng
                    Desc:扩展数组调用*/
                field = obj.GetType().GetField(strParams[0]);
                if (field != null)
                {
                    obj = field.GetValue(obj);

                    Array array = (Array)obj;
                    Int64 index = 0;
                    Int64.TryParse(strParams[1], out index);
                    if (array == null || array.Length <= index)
                        return false;

                    if (names.Length > 1)
                    {
                        obj = array.GetValue(index);
                        return SetObjectValue(obj, name.Substring(key.Length + 1), value);
                    }
                    else
                    {
                        // 忽略String表达式中的参数表
                        array.SetValue(value, index);

                        return true;
                    }
                }
            }
            else
            {
                FieldInfo[] infos = obj.GetType().GetFields();
                for (int j = 0; j < infos.Length; j++)
                {
                    FieldInfo info = infos[j];
                    if (info.Name == key || info.Name.EndsWith("." + key))
                    {
                        if (names.Length > 1)
                        {
                            object objField = info.GetValue(obj);
                            return SetObjectValue(objField, name.Substring(key.Length + 1), value);
                        }
                        else
                        {
                            info.SetValue(obj, value);
                            return true;
                        }
                    }
                }
            }
        }

        return false;
    }

    /*
     * Name: ConvetParamsToTypeForPlayMaker
     * Desc: 转换参数类型，类型检测
     *       使用反射，设置参数序列
     * Date: 4/14/2015
     * Author：XiangJiYu
     * 
     * Function: ConvetParamsToTypeForPlayMaker   
     * Param:   type                [IN]        类型
     *          obj                 [REF]       对应的参数
     *                                          传入XmlNode  传出的是打包的对应数据
     *          
     * Return:  无
    */
    public static bool ConvetParamsToTypeForPlayMaker(Type type, ref System.Object obj)
    {
        XmlNode node = obj as XmlNode;
        if (node == null)
        {
            // Debug.LogError("Unknown params infos in :" + type.Name);

            return false;
        }


        switch (Type.GetTypeCode(type))
        {
            case TypeCode.Boolean:
            case TypeCode.Char:
            case TypeCode.Byte:
            case TypeCode.Int16:
            case TypeCode.UInt16:
            case TypeCode.Int32:
            case TypeCode.UInt32:
            case TypeCode.Int64:
            case TypeCode.UInt64:
            case TypeCode.Single:
            case TypeCode.String:
                {
                    ConvertValue(Type.GetTypeCode(type), node.InnerText, ref obj);
                } break;

            case TypeCode.Object:
                {
                    /* Date:    6/26/2012
                     * Author:  XingPeng
                     * Desc:    特殊类型判定： XmlNode, List, Array 等判定
                     */
                    if (type.IsArray && type.HasElementType)
                    {
                        if (node.Name.Equals("Vector", StringComparison.OrdinalIgnoreCase) ||
                            node.Name.Equals("ARRAY", StringComparison.OrdinalIgnoreCase))
                        {
                            XmlNodeList nodeList = node.SelectNodes("./*");
                            if (nodeList.Count == 0)
                            {
                                obj = null;
                                break;
                            }

                            obj = Activator.CreateInstance(type, new object[] { nodeList.Count });

                            Array array = (Array)obj;
                            int i = 0;
                            // 提高性能
                            foreach (XmlNode nodeItem in nodeList)
                            {

                                object result = nodeItem;

                                Type elementType = type.GetElementType();
                                //如果是抽象类
                                if (elementType.IsAbstract)
                                {
                                    //根据name属性获取类型
                                    string typeStr = nodeItem.Attributes["name"].Value;

                                    if (!string.IsNullOrEmpty(typeStr))
                                    {
                                        Type extendType = Type.GetType(typeStr);

                                        //Editor域中无法获取类型时，尝试从运行域中获取
                                        if (extendType == null)
                                        {
                                            Assembly[] array_Assembly = AppDomain.CurrentDomain.GetAssemblies();
                                            for (int j = 0; j < array_Assembly.Length; j++)
                                            {
                                                string assemblyName = array_Assembly[j].GetName().Name;
                                                if (assemblyName == "Assembly-CSharp")
                                                {
                                                    extendType = array_Assembly[j].GetType(typeStr);
                                                    break;
                                                }
                                            }
                                        }
                                        if (extendType == null)
                                        {
                                            Debug.LogError("Unknown type infos in funciton name:" + typeStr);
                                            return false;
                                        }
                                        ConvetParamsToTypeForPlayMaker(extendType, ref result);
                                    }
                                }
                                else
                                {
                                    ConvetParamsToTypeForPlayMaker(type.GetElementType(), ref result);
                                }


                                array.SetValue(result, i++);
                            }
                        }
                    }
                    else if (type.IsClass || type.IsValueType)
                    {
                        if (node.Name.Equals("Object", StringComparison.OrdinalIgnoreCase) ||
                            node.Name.Equals("INT_TUPLE", StringComparison.OrdinalIgnoreCase) ||
                            node.Name.Equals("NetCall", StringComparison.OrdinalIgnoreCase))
                        {
                            XmlNodeList nodeList = node.SelectNodes("./*");
                            List<XmlNode> list = new List<XmlNode>();
                            for (int i = 0; i < node.Attributes.Count; i++)
                            {
                                XmlNode nodeItem = node.Attributes[i];
                                list.Add(nodeItem);
                            }
                            // 提高性能
                            foreach (XmlNode nodeItem in nodeList)
                            {
                                list.Add(nodeItem);
                            }


                            /* Date:    6/26/2012
                             * Author:  XingPeng
                             * Desc:    特殊类型判定： XmlNode判定
                             */
                            if (type == typeof(XmlNode))
                            {
                                break;
                            }
                            //yadou  要是类名包含FsmEvent 则必须要有 一个参数的构造函数  作者意图是 继承 FsmEvent 取名为XXXFsmEvent
                            //UIBindEvent 中的EventBindFsmEvent
                            if (type.ToString().Contains("FsmEvent")) 
                            {
                                try
                                {
                                    obj = Activator.CreateInstance(type, new object[] { "" });
                                }
                                catch (Exception)
                                {
                                    obj = Activator.CreateInstance(type);
                                    
                                }
                               
                            }
                            else
                            {
                                obj = Activator.CreateInstance(type);
                            }

                            FieldInfo[] infos = type.GetFields();
                            PropertyInfo[] array_PropertyInfo = type.GetProperties();
                            for (int i = 0; i < list.Count; i++)
                            {
                                string strFieldName = "";
                                XmlNode nodeItem = list[i];
                                XmlAttribute attr = nodeItem as XmlAttribute;
                                if (attr == null)
                                {
                                    attr = nodeItem.Attributes["name"];
                                    if (attr == null)
                                        attr = nodeItem.Attributes["prop"];
                                    if (attr == null)
                                        attr = nodeItem.Attributes["function"];

                                    if (attr != null)
                                        strFieldName = attr.Value;
                                }
                                else
                                {
                                    strFieldName = attr.Name;
                                }
                                /*if (attr == null)
                                    continue;*/

                                if (strFieldName == "")
                                {
                                    if (infos.Length < i)
                                    {
                                        continue;
                                    }

                                    FieldInfo info = infos[i];
                                    object result = nodeItem;
                                    ConvetParamsToTypeForPlayMaker(info.FieldType, ref result);

                                    info.SetValue(obj, result);
                                }
                                else
                                {
                                    for (int j = 0; j < infos.Length; j++)
                                    {
                                        FieldInfo info = infos[j];
                                        if (info.Name == strFieldName)
                                        {
                                            object result = nodeItem;
                                            try
                                            {
                                                ConvetParamsToTypeForPlayMaker(info.FieldType, ref result);
                                            }
                                            catch (Exception)
                                            {
                                                string errorString = obj.ToString();
                                                ActionManager.Add(() => { Debug.LogError("Error serialize " + errorString); return true; });
                                            }

                                            if (info.FieldType == typeof(XmlNode))
                                            {
                                                info.SetValue(obj, result);
                                                break;
                                            }
                                            if (!info.FieldType.IsArray && nodeItem.Name.Equals("ARRAY", StringComparison.OrdinalIgnoreCase))
                                            {
                                                /*
                                                 * Date:	2012/8/22
                                                 * Author:	XingPeng
                                                 * Desc:	添加空值,INT_TUPLE中传入Nil值
                                                 */
                                                break;
                                            }

                                            info.SetValue(obj, result);

                                            break;
                                        }
                                    }

                                    //属性访问器
                                    for (int j = 0; j < array_PropertyInfo.Length; j++)
                                    {
                                        PropertyInfo propertyInfo = array_PropertyInfo[j];
                                        if (propertyInfo.Name == strFieldName)
                                        {
                                            object result = nodeItem;
                                            try
                                            {
                                                ConvetParamsToTypeForPlayMaker(propertyInfo.PropertyType, ref result);
                                            }
                                            catch (Exception)
                                            {
                                                string errorString = obj.ToString();
                                                ActionManager.Add(() => { Debug.LogError("Error serialize " + errorString); return true; });
                                            }

                                            if (propertyInfo.PropertyType == typeof(XmlNode))
                                            {
                                                propertyInfo.SetValue(obj, result, null);
                                                break;
                                            }
                                            if (!propertyInfo.PropertyType.IsArray && nodeItem.Name.Equals("ARRAY", StringComparison.OrdinalIgnoreCase))
                                            {
                                                /*
                                                 * Date:	2012/8/22
                                                 * Author:	XingPeng
                                                 * Desc:	添加空值,INT_TUPLE中传入Nil值
                                                 */
                                                break;
                                            }

                                            propertyInfo.SetValue(obj, result, null);

                                            break;
                                        }
                                    }
                                }
                            }


                            //todo 判断属性prep
                        }
                    }
                    else
                    {
                        switch (type.FullName)
                        {
                            case "":
                                {
                                } break;

                            default:
                                {
                                    string errorString = type.FullName;
                                    ActionManager.Add(() => { Debug.LogError("Unknown type infos in funciton name:" + errorString); return true; });
                                } break;
                        }
                    }
                } break;

            default:
                {
                    string errorString = type.FullName;
                    ActionManager.Add(() => { Debug.LogError("Unknown type infos in funciton name:" + errorString); return true; });
                } break;
        }

        return true;
    }

    /*
     * Name: Object
     * Desc: 获取属性
     * Date: 01/05/2013
     * Author：XingPeng
     * 
     * 
     * Modify:  XingPeng
     * Date:    01/21/2014
     * Desc:    重构，增加层次解析，增加属性项解析
     * 
     * 
     * Function: GetObjectValue   
     * Param:   obj                 [REF]       目标结点
     *          name                [IN]        属性          <@开头表示属性名，否者为字段名; .增加对象层级; :函数调用; ,参数分隔>
     *          value               [IN]        属性值       
     * Return:  无
    */
    public static bool GetObjectValue(object obj, String name, out object value)
    {
        value = null;

        if (obj == null)
            return false;

        string[] names = name.Split(new char[] { '.' });
        if (names.Length > 0)
        {
            string key = names[0];
            if (key.StartsWith("@"))
            {
                if (key.Contains(":"))
                { 
                    string[] strParams = key.Split(new char[] { ':', ',' });
                    // 函数调用

                    System.Reflection.MethodInfo method = null;
                    /*XingPeng
                        Desc:扩展函数调用*/
                    method = GetFunc(obj.GetType(), strParams[0].Substring(1));
                    if (method != null)
                    {
                        if (strParams.Length > 1)
                        {
                            System.Object[] param = new System.Object[strParams.Length - 1];
                            Array.Copy(strParams, 1, param, 0, param.Length);

                            ConvetParamsToType(method, ref param);
                            value = method.Invoke(obj, param);
                        }
                        else
                        {
                            value = method.Invoke(obj, null);
                        }


                        if (names.Length > 1)
                        {
                            object objField = value;
                            GetObjectValue(objField, name.Substring(key.Length + 1), out value);
                        }

                        return true;
                    }
                }
                else
                {
                    // 属性调用

                    System.Reflection.PropertyInfo property = null;
                    /*XingPeng
                        Desc:用于隐藏MVC中的Mod*/
                    if (key.Equals("@Mod"))
                    {
                        property = obj.GetType().GetProperty(key.Substring(1), BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                    }
                    else
                    {
                        property = obj.GetType().GetProperty(key.Substring(1));
                    }
                    if (property != null)
                    {
                        value = property.GetValue(obj, null);
                        if (names.Length > 1)
                        {
                            object objField = value;
                            GetObjectValue(objField, name.Substring(key.Length + 1), out value);
                        }

                        return true;
                    }
                }
            }
            else if (key.Contains("[") && key.EndsWith("]"))
            {
                string[] strParams = key.Split(new char[] { '[', ']' });
                // 数组调用

                System.Reflection.FieldInfo field = null;
                /*XingPeng
                    Desc:扩展数组调用*/
                field = obj.GetType().GetField(strParams[0]);
                if (field != null)
                {
                    value = field.GetValue(obj);

                    Array array = (Array)value;
                    Int64 index = 0;
                    Int64.TryParse(strParams[1], out index);
                    if (array == null || array.Length <= index)
                        return false;

                    value = array.GetValue(index);
                    if (names.Length > 1)
                    {
                        object objField = value;
                        GetObjectValue(objField, name.Substring(key.Length + 1), out value);
                    }

                    return true;
                }
            }
            else
            {
                FieldInfo[] infos = obj.GetType().GetFields();
                for (int j = 0; j < infos.Length; j++)
                {
                    FieldInfo info = infos[j];
                    if (info.Name == key || info.Name.EndsWith("." + key))
                    {
                        value = info.GetValue(obj);
                        if (names.Length > 1)
                        {
                            object objField = value;
                            GetObjectValue(objField, name.Substring(key.Length + 1), out value);
                        }

                        return true;
                    }
                }
            }
        }

        return false;
    }


    /*
     * Name: Object
     * Desc: 获取属性
     *       仅对平展结构数据，进行转换
     * Date: 01/05/2013
     * Author：XingPeng
     * 
     * 
     * Modify:  XingPeng
     * Date:    01/21/2014
     * Desc:    重构，增加层次解析，增加属性项解析
     * 
     * 
     * Function: GetObjectValue   
     * Param:   obj                 [REF]       目标结点 {目标节点，直接替换参数1，直接替换参数2...}
     *          name                [IN]        属性     {字符串格式，域名1，域名2...}       <@开头表示属性名，否者为字段名; .增加对象层级>
     *          value               [OUT]       属性值   {域值1，域值2...}        
     * Return:  无
    */
    public static bool GetObjectValue(object[] obj, String[] name, out String[] value)
    {
        value = null;

        if (obj == null || obj[0] == null || name == null)
            return false;

        List<int> iValidList = new List<int>();
        String[] valueResult = new String[name.Length];
        for (int i = 0; i < name.Length; i++)
        {
            valueResult[i] = name[i];
            iValidList.Add(i);
        }
        // 第1项，放置ID
        iValidList.Remove(0);

        for (int i = 0; i < name.Length;i++ )
        {
            object result = null;
            GetObjectValue(obj[0], name[i], out result);
            if (result != null)
            {
                valueResult[i] = result.ToString();
                iValidList.Remove(i);
            }
        }


        // 增加剩余的项
        int iIndex = 1;
        if (obj.Length > 1 && iValidList.Count > 0)
        {
            for (int j = 0; j < iValidList.Count; j++)
            {
                int i = iValidList[j];

                object result = null;
                GetObjectValue(obj[iIndex], name[i], out result);
                if (result != null)
                {
                    valueResult[i] = result.ToString();
                    iValidList.Remove(i);
                    iIndex++;

                    if (obj.Length <= iIndex)
                    {
                        break;
                    }
                }
            }
        }


        if (iValidList.Count < name.Length - 1 || iIndex > 1)
        {
            value = new String[name.Length-1];
            Array.Copy(valueResult, 1, value, 0, value.Length);
            return true;
        }
        else
        {
            return false;
        }
    }
	
	
	/*
     * Name: Object
     * Desc: 设置属性
     * Date: 8/28/2012
     * Author：XingPeng
     * 
     * Function: CloneObject   
     * Param:   obj                 [REF]       目标结点
     *          name                [IN]        属性
     *          value               [IN]        属性值
     *          
     * Return:  无
    */
    public static bool CloneObject(object objSrc, ref object objDest)
    {
		if (objSrc == null)
		{
			objDest = null;
			return false;
		}
		
		if (objDest == null)
            return false;


		switch(Type.GetTypeCode(objSrc.GetType()))
		{
		case TypeCode.Boolean:
        case TypeCode.Char:
        case TypeCode.Byte:
        case TypeCode.Int16:
        case TypeCode.UInt16:
        case TypeCode.Int32:
        case TypeCode.UInt32:
        case TypeCode.Int64:
        case TypeCode.UInt64:
        case TypeCode.Single:
        case TypeCode.String:
            {
				objDest = objSrc;
            } break;
			
		case TypeCode.Object:
			{
				Type type = objSrc.GetType();
				
				if (type.IsArray && type.HasElementType)
				{
					Array objItemSrc = objSrc as Array;

					if (objSrc == null)
					{
						objDest = null;
					}
					else
					{
						Type  typeDest = objDest.GetType().GetElementType();
						Array objItemDest = Activator.CreateInstance(objDest.GetType(), new object[] { objItemSrc.Length }) as Array;
						objDest = objItemDest;
						for(int i=0;i<objItemDest.Length; i++)
						{
							object objItem = Activator.CreateInstance(typeDest);
							CloneObject(objItemSrc.GetValue(i), ref objItem);
							objItemDest.SetValue(objItem, i);
						}
					}
				}
				else if (type.IsClass)
				{
					FieldInfo[] infos = objSrc.GetType().GetFields();
                    for (int j = 0; j < infos.Length; j++)
                    {
                        FieldInfo info = infos[j];
						object objItemSrc = info.GetValue(objSrc);
					
						FieldInfo infoDesct = objDest.GetType().GetField(info.Name);
						if (infoDesct == null)
							continue;
					
						object objItemDest = CreateClass(objItemSrc, infoDesct);
						CloneObject(objItemSrc, ref objItemDest);
						infoDesct.SetValue(objDest, objItemDest);
					}
				}
			} break;
			
		default:
			{
				//SetObjectValue(objDest, info.Name, info.GetValue(objSrc).ToString());
			} break;
			
		}
		

        return true;
    }
	
	
	/*
     * Name: Object
     * Desc: 设置属性
     * Date: 8/28/2012
     * Author：XingPeng
     * 
     * Function: CreateClass   
     * Param:   objSrc              [REF]       源
     *          objDest             [IN]        目标
     *          infoDest            [IN]        目标信息
     *          
     * Return:  无
    */
	private static object CreateClass(object objSrc, FieldInfo infoDest)
	{
		if (objSrc == null)
			return null;
		
		Type type = objSrc.GetType();
		if (type.IsArray && type.HasElementType)
		{
			Array objItemDest = Activator.CreateInstance(infoDest.FieldType, new object[] { (objSrc as Array).Length }) as Array;
			return objItemDest;
		}
		else if (Type.GetTypeCode(type) == TypeCode.String)
        {
            return Activator.CreateInstance(infoDest.FieldType, new object[] { (char)0, 1 });
        }
		else
		{
			return Activator.CreateInstance(infoDest.FieldType);
		}
		
		return null;
	}


    /*
     * Name: XML
     * Desc: 添加属性
     * Date: 7/30/2012
     * Author：XingPeng
     * 
     * Function: AddAttribute   
     * Param:   parent              [REF]       目标结点
     *          name                [IN]        属性
     *          value               [IN]        属性值
     *          
     * Return:  无
    */
    public static void AddAttribute(XmlNode parent, string name, string value)
    {
        if (parent == null)
            return;

        XmlAttribute attr = parent.Attributes[name];
        if (attr == null)
        {
            attr = parent.OwnerDocument.CreateAttribute(name);
            parent.Attributes.Append(attr);
        }

        attr.Value = value;
    }


    /*
     * Name: XML
     * Desc: 获取属性
     * Date: 7/30/2012
     * Author：XingPeng
     * 
     * Function: GetAttribute   
     * Param:   parent              [REF]       目标结点
     *          name                [IN]        属性
     *          value               [OUT]       属性值
     *          
     * Return:  无
    */
    public static bool GetAttribute(XmlNode parent, string name, out string value)
    {
        value = "";

        XmlAttribute attr = parent.Attributes[name];
        if (attr == null)
        {
            return false;
        }

        value = attr.Value;
        return true;
    }


    /*
     * Name: XML
     * Desc: 添加节点
     * Date: 7/30/2012
     * Author：XingPeng
     * 
     * Function: AddNode   
     * Param:   parent              [REF]       父结点
     *          name                [IN]        属性
     *          value               [IN]        属性值
     *          
     * Return:  无
    */
    public static void AddNode(XmlNode parent, string name, string value)
    {
        if (parent == null)
            return;

        XmlNode node = parent.SelectSingleNode("./" + name);

        if (node == null)
        {
            Regex rx = new Regex(@"(\w+)\[\@(\w+)\=\'([\w\d]+)\'\]");
            Match m = rx.Match(name);
            if (m.Success && m.Groups.Count > 3)
            {
                node = parent.OwnerDocument.CreateNode(XmlNodeType.Element, m.Groups[1].Value, "");
                parent.AppendChild(node);

                AddAttribute(node, m.Groups[2].Value, m.Groups[3].Value);
            }
            else
            {
                node = parent.OwnerDocument.CreateNode(XmlNodeType.Element, name, "");
                parent.AppendChild(node);
            }
        }

        if (node.Value == null)
        {
            node.InnerText = value;
        }
        else
        {
            node.Value = value;
        }
    }


    #region //PC下把数据结构转为2进制 建议用protocol-net 效率比.net自带的高很多


   public static void SerializeToBinFile(object obj,string binfilename)
   {
       FileStream fileStream = new FileStream("../ClientRes/BinFile/" + binfilename, FileMode.Create, FileAccess.ReadWrite);
       BinaryFormatter b = new BinaryFormatter();
       b.Serialize(fileStream, obj);
       fileStream.Close();
   }

   public static T DeSerializeFromBytes<T>(byte[] data) where T : class
    {
        if (data == null) return null;
        BinaryFormatter bf = new BinaryFormatter();
        MemoryStream ms = new MemoryStream(data);
        object ret = bf.Deserialize(ms);
        ms.Close();
        return ret as T;
    }
   public static object DeSerializeFromBytes(byte[] data)
   {
       if(data==null)return null;
       BinaryFormatter bf = new BinaryFormatter();
       MemoryStream ms = new MemoryStream(data);
       object ret = bf.Deserialize(ms);
       ms.Close();
       return ret;
   }

    public static object DeSerializeFromBinFile(string binfilename)
   {
     
        
        
      FileStream fs = new FileStream(binfilename, FileMode.Open,FileAccess.ReadWrite);
       
       BinaryFormatter b = new BinaryFormatter();
       object ret = b.Deserialize(fs);
      fs.Close();
      return ret;
   }
   

    #endregion

}