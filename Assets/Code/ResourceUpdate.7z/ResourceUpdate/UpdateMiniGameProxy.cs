﻿using System;
using System.Collections;
using System.IO;
using UnityEngine;
using Assets.Game.System.Module.ResoureManager;
using LuaInterface;
using System.Threading;

public class UpdateMiniGameProxy : Singleton<UpdateMiniGameProxy>
{
    /// <summary>
    /// 获取小游戏真实路径
    /// </summary>
    /// <param name="game_name"></param>
    /// <returns></returns>
    public string GetMiniGamePath(string game_name)
    {
        string sub_path = "assetbundle/" + game_name;

        string dirPath = Application.persistentDataPath + "/ClientRes/" + ResourcePath.ReLocatePath(sub_path);

        return dirPath;
    }

    /// <summary>
    /// 获取文件夹大小
    /// </summary>
    /// <param name="dirPath">完整路径</param>
    /// <returns></returns>
    public long GetDirectoryLength(string dirPath)
    {
        if (dirPath == null || dirPath == "")
            return 0;

        //判断给定的路径是否存在,如果不存在则退出
        if (!Directory.Exists(dirPath))
            return 0;
        long len = 0;

        //定义一个DirectoryInfo对象
        DirectoryInfo di = new DirectoryInfo(dirPath);

        //通过GetFiles方法,获取di目录中的所有文件的大小
        foreach (FileInfo fi in di.GetFiles())
        {
            len += fi.Length;
        }

        //获取di中所有的文件夹,并存到一个新的对象数组中,以进行递归
        DirectoryInfo[] dis = di.GetDirectories();
        if (dis.Length > 0)
        {
            for (int i = 0; i < dis.Length; i++)
            {
                len += GetDirectoryLength(dis[i].FullName);
            }
        }
        return len;
    }

    /// <summary>
    /// 删除文件
    /// </summary>
    /// <param name="file_path"></param>
    public void DeleteFile(string file_path)
    {
        ResoureUpdateProxy.DeleteDirectory(file_path);

        //更新资源xml
        ResoureUpdateProxy.UpdateResXml();
    }

    /// <summary>
    /// 更新资源列表
    /// </summary>
    public void UpdateAddRes()
    {
        //更新资源列表
        ResoureUpdateProxy.UpdateResXml();
    }

    private LocalVersion localVersion;
    string xml_file_name = "";
    public string GetXmlFile(string file_name)
    {
        xml_file_name = file_name;
        string tempText = GlobalFunction.LoadPersistentFile(file_name, Application.persistentDataPath + "/ClientRes/");

        if (!string.IsNullOrEmpty(tempText))
        {
            localVersion = new LocalVersion();
            ResoureUpdateProxy.ConvetStringToLocalVersion(tempText, ref localVersion);
        }

        return tempText;
    }

    /// <summary>
    /// 保存或创建xml
    /// </summary>
    /// <param name="file_name"></param>
    /// <param name="xml_string"></param>
    public void CreateOrSaveXmlFile(string file_name, string xml_string)
    {
        GlobalFunction.SaveFiles(xml_string, file_name, "/ClientRes/");
    }

    public void GetServerVersionData(string server_path, LuaFunction p_callback)
    {
        //读取资源服务器版本文件
        ResourceLoader.Instance.StartCoroutine(LoadResServerVersion(server_path, p_callback));
    }
    VersionData serverVersion = null;
    //获取服务器版本文件
    private IEnumerator LoadResServerVersion(string resServer, LuaFunction p_callback)
    {
        //ResourceUpdatePanel.instance.ResoureUpdateText("正在读取服务器版本号...");
        long timestamp = (long)(System.DateTime.Now - TimeZone.CurrentTimeZone.ToLocalTime(new System.DateTime(1970, 1, 1))).TotalSeconds;
        WWW www = new WWW(resServer + "?timestamp=" + timestamp);
        yield return www;

        serverVersion = new VersionData();
        if (string.IsNullOrEmpty(www.error) && !string.IsNullOrEmpty(www.text))
        {
            ResoureUpdateProxy.ConvetStringToVersionData(www.text, ref serverVersion);

            Debug.Log("######## 资源服务器版本文件解析成功");
            p_callback.Call(www.text);
        }
        else
        {
            p_callback.Call(serverVersion);
            //ResourceUpdatePanel.instance.ResoureUpdateText("资源服务器版本文件读取失败！");
            Debug.Log("######## 资源服务器版本文件读取失败");
        }
        www = null;
    }

    LuaFunction m_success = null;
    LuaFunction m_failed = null;
    LuaFunction m_update = null;
    public void DoDownLoad(string resServer, string patch, LuaFunction success, LuaFunction failed, LuaFunction update)
    {
        m_success = success;
        m_failed = failed;
        m_update = update;

        string[] urlsTemp = new string[1];
        urlsTemp[0] = resServer + patch;
        Debug.Log("##########urlsTemp=" + urlsTemp);
        FileDownloadHelper.Instance.StartRequestAllFileLength(new GetUrlsSizeRequire()
        {
            urls = urlsTemp,
            pSuccess = OnGetAllFileSizeSuccessIntegrant, // 后续处理在这里
            pFailed = OnGetAllFileSizeFailed
        });
    }

    private void OnGetAllFileSizeSuccessIntegrant(long totalSize)
    {
        if (localVersion == null)
        {
            m_failed.Call();
            return;
        }

        float downLoadSize = (float)(totalSize / 1024f) / 1024f;
        if (downLoadSize < 0.01f)
        {
            downLoadSize = 0.01f;
        }
        string text = "";
        if (Application.internetReachability == NetworkReachability.ReachableViaLocalAreaNetwork)
            text = string.Format("必须更新后才可进入游戏！\n资源包大小：{0:0.00}M", downLoadSize);
        else
            text = string.Format("必须更新后才可进入游戏！（当前非WIFI环境）\n资源包大小：{0:0.00}M", downLoadSize);

        PatchData patch = CheckPath(localVersion.localVersion);
        if (patch != null)
        {
            //ResourceUpdatePanel.instance.ResoureUpdateText("正在下载补丁包 " + patch.newVersion);
            DownLoadPatchHelper(patch);
        }
        else
        {
            Debug.Log("没有找到更新包");
        }
        //ResourceUpdatePanel.instance.Close();
    }
    private PatchData CheckPath(string version)
    {
        if (serverVersion != null && serverVersion.patchs != null)
        {
            for (int i = 0; i < serverVersion.patchs.Length; i++)
            {
                if (serverVersion.patchs[i].oldVersion.Equals(version))
                {
                    return serverVersion.patchs[i];
                }
            }
        }

        return null;
    }

    private void OnGetAllFileSizeFailed(int errorCode)
    {
        //ResourceUpdatePanel.instance.ResoureUpdateText("获取更新包档大小失败：" + errorCode);
        Debug.Log("获取更新包档大小失败");
    }

    private static bool isExtractSuccess = false;

    //断线重连下载
    private void DownLoadPatchHelper(PatchData patch)
    {
        FileDownloadHelper.Instance.StartContinueDownload(new ContinueDownloadRequire()
        {
            url = ResoureUpdateProxy.instance.ResServerUrl + patch.patch,
            pSucess = (filePath) =>
            {
                //校验Hash值
                if (!string.IsNullOrEmpty(patch.hash))
                {
                    string hash = GlobalFunction.FileMd5(filePath);
                    if (!hash.Equals(patch.hash))
                    {
                        //ResourceUpdatePanel.instance.ResoureUpdateText("文件校验失败，请重新下载！");
                        Debug.Log("文件校验失败，请重新下载！" + "\npatch.hash=" + patch.hash + "\nfilePath=" + filePath + "\nhash=" + hash);
                        return;
                    }
                }

                //bool isExtract = false;
                //// 解压文件
                //try
                //{
                //    Zip zip = new Zip();
                //    isExtract = zip.Extract(filePath, GlobalFunction.LOCAL_RES_PATH, 4096, true);
                //}
                //catch (Exception e)
                //{
                //    Debug.LogError(e.ToString());
                //    isExtract = false;
                //}

                //if (!isExtract)
                //{
                //    //ResUpdateState = false;
                //    //ResourceUpdatePanel.instance.ResoureUpdateText(patch.patch + " 解压失败！");
                //    Debug.Log(patch.patch + " 解压失败！");
                //}
                //else
                //{
                //    //更新本地版本信息
                //    localVersion.localVersion = patch.newVersion;
                //    ////ResourceUpdatePanel.instance.ResoureUpdateVersion(localVersion == null ? "未知" : localVersion.localVersion, serverVersion == null ? "未知" : serverVersion.version);
                //    ResoureUpdateProxy.SaveFile(localVersion, xml_file_name, "/ClientRes");
                //    ////调用一次资源释放
                //    ////System.GC.Collect();
                //    ////继续检测版本更新
                //    //CheckUpdate();
                //    m_success.Call();
                //}

                isExtractSuccess = false;
                Thread unZipThread = new Thread(new ParameterizedThreadStart(UnZipData));
                unZipThread.Start(filePath);

                ActionManager.Add(() => {

                    if(isExtractSuccess)
                    {
                        if (!isExtractSuccess)
                        {
                            //ResUpdateState = false;
                            //ResourceUpdatePanel.instance.ResoureUpdateText(patch.patch + " 解压失败！");
                            Debug.Log(patch.patch + " 解压失败！");
                        }
                        else
                        {
                            //更新本地版本信息
                            localVersion.localVersion = patch.newVersion;
                            ////ResourceUpdatePanel.instance.ResoureUpdateVersion(localVersion == null ? "未知" : localVersion.localVersion, serverVersion == null ? "未知" : serverVersion.version);
                            ResoureUpdateProxy.SaveFile(localVersion, xml_file_name, "/ClientRes");
                            ////调用一次资源释放
                            ////System.GC.Collect();
                            ////继续检测版本更新
                            //CheckUpdate();
                            m_success.Call();
                        }
                        return true;
                    }

                    return false;
                });
            },
            pFailed = (pMsg) =>
            {
                //ResUpdateState = false;
                //ResourceUpdatePanel.instance.ResoureUpdateText(patch.patch + " 下载失败！");
                Debug.Log(patch.patch + " 下载失败！");
                m_failed.Call();
            },
            pUpdate = (currentNum, totalNum, url) =>
            {
                float progress = (float)currentNum / (float)totalNum;
                //ResourceUpdatePanel.instance.ResoureUpdateBar(progress);
                m_update.Call(currentNum, totalNum);
            }
        });
    }

    private void UnZipData(System.Object file)
    {
        string filePath = (string)file;

        // 解压文件
        try
        {
            Zip zip = new Zip();
            isExtractSuccess = zip.Extract(filePath, GlobalFunction.LOCAL_RES_PATH, 4096, true);
        }
        catch (Exception e)
        {
            Debug.LogError(e.ToString());
            isExtractSuccess = false;
        }
    }
}