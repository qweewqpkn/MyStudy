﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;
using System.Text.RegularExpressions;

/// <summary>
/// 扩展方法汇总
/// </summary>

public static class ExtendFunctions
{
    static public int Total(this Array array)
    {
        if (array == null) return 0;
        return array.Length;
    }
    

    static public int Total<T>(this List<T> list)
    {
        if (list == null) return 0;
        return list.Count;
    }

    public static bool IsNullOrEmpty(this string str)
    {
        return string.IsNullOrEmpty(str);
    }

    public static string Unescape(this string str)
    {
        return Regex.Unescape(str);
    }
}
