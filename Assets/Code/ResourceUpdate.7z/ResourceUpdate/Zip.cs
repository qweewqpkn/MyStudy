using ICSharpCode.SharpZipLib.Zip;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using UnityEngine;

namespace Assets.Game.System.Module.ResoureManager
{
    public class Zip
    {
        /// <summary>
        /// ѹ���ļ���
        /// </summary>
        /// <param name="dirPath">ѹ���ļ��е�·��</param>
        /// <param name="fileName">���ɵ�zip�ļ�·��</param>
        /// <param name="level">ѹ������ 0 - 9 0�Ǵ洢���� 9�����ѹ��</param>
        /// <param name="bufferSize">��ȡ�ļ��Ļ�������С</param>
        public void CompressDirectory(string dirPath, string fileName, int level, int bufferSize)
        {
            byte[] buffer = new byte[bufferSize];
            using (ZipOutputStream s = new ZipOutputStream(File.Create(fileName)))
            {
                s.SetLevel(level);
                CompressDirectory(dirPath, dirPath, s, buffer);
                s.Finish();
                s.Close();
            }
        }

        /// <summary>
        /// ѹ���ļ���
        /// </summary>
        /// <param name="root">ѹ���ļ���·��</param>
        /// <param name="path">ѹ���ļ����ڵ�ǰҪѹ�����ļ���·��</param>
        /// <param name="s"></param>
        /// <param name="buffer">��ȡ�ļ��Ļ�������С</param>
        private void CompressDirectory(string root, string path, ZipOutputStream s, byte[] buffer)
        {
            root = root.TrimEnd('/') + "//";
            string[] fileNames = Directory.GetFiles(path);
            string[] dirNames = Directory.GetDirectories(path);
            string relativePath = path.Replace(root, "");
            if (relativePath != "")
            {
                relativePath = relativePath.Replace("//", "/") + "/";
            }
            int sourceBytes;
            var lst1 = fileNames;
            for (int k1=0, max1=lst1.Total(); k1<max1; ++k1)
            {   var file = lst1[k1];

                ZipEntry entry = new ZipEntry(relativePath + Path.GetFileName(file));
                entry.DateTime = DateTime.Now;
                s.PutNextEntry(entry);
                using (FileStream fs = File.OpenRead(file))
                {
                    do
                    {
                        sourceBytes = fs.Read(buffer, 0, buffer.Length);
                        s.Write(buffer, 0, sourceBytes);
                    } while (sourceBytes > 0);
                }
            }

            var lst2 = dirNames;
            for (int k2=0, max2=lst2.Total(); k2<max2; ++k2)
            {   var dirName = lst2[k2];
                string relativeDirPath = dirName.Replace(root, "");
                ZipEntry entry = new ZipEntry(relativeDirPath.Replace("//", "/") + "/");
                s.PutNextEntry(entry);
                CompressDirectory(root, dirName, s, buffer);
            }
        }

        /// <summary>
        /// ��ѹ��zip�ļ�
        /// </summary>
        /// <param name="zipFilePath">��ѹ��zip�ļ�·��</param>
        /// <param name="extractPath">��ѹ�����ļ���·��</param>
        /// <param name="bufferSize">��ȡ�ļ��Ļ�������С</param>
        public bool Extract(string zipFilePath, string extractPath, int bufferSize, bool deleteZip = false)
        {
            //extractPath = extractPath.TrimEnd('/') + "//";
            byte[] data = new byte[bufferSize];
            int size;
            byte state = 0;
            string infos = "";
            try
            {
                using (ZipInputStream s = new ZipInputStream(File.OpenRead(zipFilePath)))
                {
                    ZipEntry entry;
                    while ((entry = s.GetNextEntry()) != null)
                    {
                        Debug.Log(entry.Name);
                        state = 1;
                        infos = entry.Name;
                        string directoryName = Path.GetDirectoryName(entry.Name);
                        state = 2;
                        string fileName = Path.GetFileName(entry.Name);

                        //�ȴ���Ŀ¼
                        if (directoryName.Length > 0)
                        {
                            state = 3;
                            infos = extractPath + directoryName;
                            Directory.CreateDirectory(extractPath + directoryName);
                        }

                        if (fileName != String.Empty)
                        {
                            state = 4;
                            infos = entry.Name;
                            using (FileStream streamWriter = File.Create(extractPath + directoryName + "//" + fileName))
                            {
                                while (true)
                                {
                                    size = s.Read(data, 0, data.Length);
                                    if (size > 0)
                                    {
                                        streamWriter.Write(data, 0, size);
                                    }
                                    else
                                    {
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    if (deleteZip)
                    {
                        state = 5;
                        File.Delete(zipFilePath);
                    }
                }
            }
            catch (Exception e)
            {
                switch (state)
                {
                    case 0:
                        Debug.LogError("File.OpenRead " + zipFilePath);
                        break;
                    case 1:
                        Debug.LogError("Path.GetDirectoryName " + infos);
                        break;
                    case 2:
                        Debug.LogError("Path.fileName " + infos);
                        break;
                    case 3:
                        Debug.LogError("Directory.CreateDirectory " + infos);
                        break;
                    case 4:
                        Debug.LogError("File.Create " + infos);
                        break;
                    case 5:
                        Debug.LogError("File.Delete " + zipFilePath);
                        break;
                    default:
                        break;
                }
                Debug.LogError(e.ToString());
                return false;
            }
            

            return true;
        }

    }
}
